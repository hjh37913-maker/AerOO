package com.aero.browser

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.*
import com.google.gson.Gson
import java.util.UUID

// ═════════════════════════ Редактор ═════════════════════════
// Весь інтерфейс редактора "носить" поточну тему: фон, скло, шрифт, акцент.

private class Pal(
    val ink: Int, val muted: Int, val acc: Int, val onAcc: Int,
    val fill: Int, val opaque: Int, val stroke: Int, val chip: Int, val base: Int,
    val tfR: Typeface, val tfB: Typeface
)

class ThemeStudioActivity : Activity() {

    companion object { const val REQ_IMG = 77 }

    private val MATCH = -1
    private val WRAP = -2

    private lateinit var saved: AeroTheme
    private lateinit var draft: AeroTheme
    private lateinit var pal: Pal
    private val undoStack = ArrayDeque<AeroTheme>()
    private val redoStack = ArrayDeque<AeroTheme>()
    private var role = 0
    private var tab = 0
    private var syncing = false
    private var staticPhase = true
    private val refreshers = mutableListOf<() -> Unit>()
    private val live = mutableListOf<() -> Unit>()
    private val themed = mutableListOf<() -> Unit>()
    private val themedStatic = mutableListOf<() -> Unit>()
    private var cKey: String? = null
    private var cBmp: Bitmap? = null
    private var tfKeyA = -1
    private var tfRA: Typeface = Typeface.DEFAULT
    private var tfBA: Typeface = Typeface.DEFAULT
    private var ambient: ValueAnimator? = null
    private val rootBg = BgDrawable(AeroTheme(), null)
    private lateinit var rootView: LinearLayout
    private val glassViews = mutableListOf<GlassLayout>()
    private var animateCards = false
    private var cardIdx = 0
    private var lastAmb = 0L

    private lateinit var preview: PreviewView
    private lateinit var nameView: TextView
    private lateinit var dirtyDot: TextView
    private lateinit var content: LinearLayout
    private val tabChips = mutableListOf<TextView>()
    private val modeChips = mutableListOf<TextView>()
    private var hexField: EditText? = null

    private val tabNames = listOf("Теми", "Колір", "Скло", "Форма", "Текст", "Фон", "Рух")
    private val baseRoles = listOf("Фон", "Поверхня", "Текст", "Другорядний", "Акцент")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun warnColor() = if (lum(pal.opaque) > 0.5) argb(0xFFB45309) else argb(0xFFFFC27A)
    private fun okColor() = if (lum(pal.opaque) > 0.5) argb(0xFF15803D) else argb(0xFF86EFAC)

    // ── кольори за ролями: 0..4 базові, 10+ точки градієнта ──
    private fun getC(i: Int): Int = when (i) {
        0 -> draft.background
        1 -> draft.surface
        2 -> draft.textPrimary
        3 -> draft.textSecondary
        4 -> draft.accent
        else -> draft.stops.getOrElse(i - 10) { draft.background }
    }

    private fun setC(i: Int, c: Int) {
        draft = when (i) {
            0 -> draft.copy(background = c)
            1 -> draft.copy(surface = c)
            2 -> draft.copy(textPrimary = c)
            3 -> draft.copy(textSecondary = c)
            4 -> draft.copy(accent = c)
            else -> {
                val l = draft.stops.toMutableList()
                if (i - 10 in l.indices) l[i - 10] = c
                draft.copy(stops = l)
            }
        }
    }

    private fun computePal(): Pal {
        val d = draft
        val base = when (d.bgMode) {
            1, 2 -> avgStops(d.stops, d.background)
            3 -> blend(d.background, Color.BLACK, 0.45f)
            else -> d.background
        }
        val a = maxOf(d.glassAlpha, 58) / 100f
        val surf = blend(d.surface, d.accent, d.tint / 100f)
        val opaque = blend(base, surf, a)
        // редактор лишається читабельним навіть при поганій палітрі користувача
        val ink = if (contrast(d.textPrimary, opaque) >= 4.5) d.textPrimary else onColor(opaque)
        val acc = if (contrast(d.accent, opaque) >= 2.3) d.accent else ink
        val key = d.font * 10 + d.weight
        if (key != tfKeyA) {
            tfKeyA = key
            tfRA = ThemeEngine.typeface(d, false)
            tfBA = ThemeEngine.typeface(d, true)
        }
        return Pal(ink, ink.withAlpha(175), acc, onColor(acc), surf.withAlpha((a * 255).toInt()), opaque,
            ink.withAlpha(44), ink.withAlpha(30), base, tfRA, tfBA)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        saved = savedInstanceState?.getString("saved")?.let { ThemeStore.fromRaw(it) } ?: ThemeEngine.current(this)
        draft = savedInstanceState?.getString("draft")?.let { ThemeStore.fromRaw(it) } ?: saved
        tab = savedInstanceState?.getInt("tab", 0) ?: 0
        pal = computePal()
        rootBg.t = draft
        setContentView(buildUi())
        refreshAll()
        preview.play()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("saved", ThemeStore.raw(saved))
        outState.putString("draft", ThemeStore.raw(draft))
        outState.putInt("tab", tab)
    }

    override fun onPause() { super.onPause(); ambient?.pause() }
    override fun onResume() { super.onResume(); ambient?.resume() }
    override fun onDestroy() { ambient?.cancel(); ambient = null; super.onDestroy() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (draft != saved) confirm("Незбережені зміни", "Відкинути зміни та вийти?") { finish() } else finish()
    }

    // ═════ Будівники UI (кожен елемент реєструє "перефарбування") ═════

    private fun reg(r: () -> Unit) {
        (if (staticPhase) themedStatic else themed).add(r)
        r()
    }

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun tv(text: String, size: Float, kind: Int = 0, bold: Boolean = false, mono: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            reg {
                setTextColor(when (kind) { 0 -> pal.ink; 1 -> pal.muted; else -> pal.acc })
                typeface = if (mono) Typeface.MONOSPACE else if (bold) pal.tfB else pal.tfR
            }
        }

    private fun glass(v: View, radiusDp: Int) {
        val g = GradientDrawable().apply { cornerRadius = dp(radiusDp).toFloat() }
        v.background = g
        reg { g.setColor(pal.fill); g.setStroke(dp(1), pal.stroke) }
    }

    private fun btn(text: String, filled: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 14f
        gravity = Gravity.CENTER
        minHeight = dp(44)
        setPadding(dp(16), dp(8), dp(16), dp(8))
        val g = GradientDrawable().apply { cornerRadius = dp(14).toFloat() }
        background = g
        reg {
            typeface = pal.tfB
            setTextColor(if (filled) pal.onAcc else pal.acc)
            g.setColor(if (filled) pal.acc else pal.acc.withAlpha(36))
        }
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onClick() }
    }

    private fun ibtn(kind: Int, onClick: () -> Unit) = IconView(this, kind).apply {
        val g = GradientDrawable().apply { cornerRadius = dp(14).toFloat() }
        background = g
        reg { color = pal.ink; g.setColor(pal.chip) }
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onClick() }
    }

    private fun applyChip(t: TextView) {
        val sel = t.tag == true
        t.setTextColor(if (sel) pal.onAcc else pal.ink)
        t.typeface = pal.tfB
        (t.background as? GradientDrawable)?.setColor(if (sel) pal.acc else pal.chip)
    }

    private fun styleChip(t: TextView, sel: Boolean) { t.tag = sel; applyChip(t) }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 13f
        gravity = Gravity.CENTER
        minHeight = dp(40)
        setPadding(dp(14), dp(6), dp(14), dp(6))
        background = GradientDrawable().apply { cornerRadius = dp(20).toFloat() }
        tag = selected
        reg { applyChip(this) }
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onClick() }
    }

    private fun hscroll(v: View) = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(v)
    }

    private fun card(): GlassLayout = GlassLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(18))
        backdrop = rootBg
        host = rootView
        glassViews.add(this)
        reg {
            fill = pal.fill
            stroke = pal.stroke
            radiusPx = dp(24).toFloat()
            blurPx = dp(draft.blur).toFloat()
            highlight = draft.highlight
            invalidate()
        }
    }

    private fun addCard(c: View) {
        content.addView(c, lp(MATCH, WRAP, t = 2, b = 12))
        if (animateCards && draft.anim > 0) {
            c.alpha = 0f
            c.translationY = dp(18).toFloat()
            c.animate().alpha(1f).translationY(0f)
                .setStartDelay(minOf(cardIdx, 6) * 50L)
                .setDuration(draft.animMs.toLong() + 100)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
        cardIdx++
    }
    private fun heading(s: String) = tv(s, 18f, 0, true)
    private fun caption(s: String) = tv(s, 12.5f, 1).apply { setPadding(0, dp(2), 0, dp(6)) }

    private fun seek(label: String, min: Int, max: Int, unit: String, get: () -> Int, set: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(2)) }
        val row = LinearLayout(this)
        val lab = tv(label, 13f, 0)
        val value = tv("", 12f, 2, false, true)
        row.addView(lab, lp(0, WRAP).apply { weight = 1f })
        row.addView(value)
        val sb = SeekBar(this).apply { this.max = max - min }
        reg {
            sb.progressTintList = ColorStateList.valueOf(pal.acc)
            sb.thumbTintList = ColorStateList.valueOf(pal.acc)
            sb.progressBackgroundTintList = ColorStateList.valueOf(pal.ink.withAlpha(70))
        }
        val step = maxOf(1, (max - min) / 24)
        var lastTick = -1000
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = "${p + min}$unit"
                if (fromUser && !syncing) {
                    if (Math.abs(p - lastTick) >= step) { lastTick = p; sb.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
                    set(p + min)
                    changed()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) { pushUndo(); lastTick = -1000 } // один запис історії на жест
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        refreshers.add { syncing = true; sb.progress = get() - min; value.text = "${get()}$unit"; syncing = false }
        box.addView(row)
        box.addView(sb)
        return box
    }

    /** set повертає true, якщо значення змінено. rebuild — перебудувати вкладку після зміни. */
    private fun choice(options: List<String>, get: () -> Int, rebuild: Boolean = false, set: (Int) -> Boolean): View {
        val row = LinearLayout(this)
        val chips = mutableListOf<TextView>()
        options.forEachIndexed { i, o ->
            val c = chip(o, false) {
                if (get() != i) {
                    pushUndo()
                    if (set(i)) {
                        changed()
                        if (rebuild) showTab(tab) else chips.forEachIndexed { j, x -> styleChip(x, j == get()) }
                    } else if (undoStack.isNotEmpty()) undoStack.removeLast()
                }
            }
            chips.add(c)
            row.addView(c, lp(WRAP, WRAP, r = 8, t = 4))
        }
        refreshers.add { chips.forEachIndexed { j, x -> styleChip(x, j == get()) } }
        return hscroll(row)
    }

    private fun buildUi(): View {
        staticPhase = true
        val wide = resources.configuration.screenWidthDp >= 720
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            background = rootBg
        }
        rootView = root

        // верхня панель
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(6)) }
        bar.addView(ibtn(IconView.BACK) { onBackPressed() }, lp(dp(44), dp(44), r = 10))
        val tb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tb.addView(tv("AERO · СТУДІЯ ТЕМ", 10f, 1, true).apply { letterSpacing = 0.14f })
        val nameRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        nameView = tv("", 22f, 0, true).apply { setSingleLine() }
        dirtyDot = tv("  ●", 12f, 0).apply { visibility = View.GONE; reg { setTextColor(warnColor()) } }
        nameRow.addView(nameView)
        nameRow.addView(dirtyDot)
        tb.addView(nameRow)
        tb.setOnLongClickListener { internals(); true }
        bar.addView(tb, lp(0, WRAP).apply { weight = 1f })
        bar.addView(ibtn(IconView.UNDO) { undo() }, lp(dp(44), dp(44), r = 8))
        bar.addView(ibtn(IconView.REDO) { redo() }, lp(dp(44), dp(44), r = 8))
        bar.addView(btn("Зберегти", true) { save() })
        root.addView(bar, lp(MATCH, WRAP))

        // прев'ю + режими
        preview = PreviewView(this)
        val modeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        listOf("Старт", "Вкладки", "Діалог").forEachIndexed { i, n ->
            val c = chip(n, i == 0) {
                preview.mode = i
                modeChips.forEachIndexed { j, x -> styleChip(x, j == i) }
                preview.play()
            }
            modeChips.add(c)
            modeRow.addView(c, lp(WRAP, WRAP, r = 8))
        }
        modeRow.addView(View(this), lp(dp(8), 1))
        val compare = btn("До / після") {}.apply {
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { preview.t = saved; preview.bmp = bmpFor(saved); preview.invalidate() }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> syncPreview()
                }
                true
            }
        }
        modeRow.addView(compare, lp(WRAP, WRAP, r = 8))
        modeRow.addView(btn("На весь екран", true) { showcase() })
        val previewCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        previewCol.addView(preview, if (wide) lp(MATCH, 0).apply { weight = 1f } else lp(MATCH, dp(250)))
        previewCol.addView(hscroll(modeRow), lp(MATCH, WRAP, t = 8, b = 4))

        // керування
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tabsRow = LinearLayout(this)
        tabNames.forEachIndexed { i, n ->
            val c = chip(n, i == tab) { showTab(i, true) }
            tabChips.add(c)
            tabsRow.addView(c, lp(WRAP, WRAP, r = 8))
        }
        controls.addView(hscroll(tabsRow), lp(MATCH, WRAP, t = 6, b = 6))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(4), dp(2), dp(28)) }
        controls.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
            setOnScrollChangeListener { _, _, _, _, _ -> glassViews.forEach { it.invalidate() } }
        }, lp(MATCH, 0).apply { weight = 1f })

        if (wide) {
            val main = LinearLayout(this).apply { setPadding(dp(16), 0, dp(16), dp(12)) }
            main.addView(previewCol, lp(0, MATCH, r = 16).apply { weight = 1.1f })
            main.addView(controls, lp(0, MATCH).apply { weight = 1f })
            root.addView(main, lp(MATCH, 0).apply { weight = 1f })
        } else {
            previewCol.setPadding(dp(16), dp(4), dp(16), 0)
            controls.setPadding(dp(16), 0, dp(16), 0)
            root.addView(previewCol, lp(MATCH, WRAP))
            root.addView(controls, lp(MATCH, 0).apply { weight = 1f })
        }
        staticPhase = false
        return root
    }

    // ═════ Вкладки ═════

    private fun showTab(i: Int, animate: Boolean = false) {
        tab = i
        animateCards = animate
        cardIdx = 0
        glassViews.clear()
        refreshers.clear()
        live.clear()
        themed.clear()
        hexField = null
        content.removeAllViews()
        when (i) {
            0 -> tabThemes()
            1 -> tabColors()
            2 -> tabGlass()
            3 -> tabShape()
            4 -> tabText()
            5 -> tabBackground()
            else -> tabAnim()
        }
        if (i in 1..6) {
            content.addView(btn("Скинути категорію до збереженого") { resetCat(i) }, lp(MATCH, WRAP, b = 8))
        }
        refreshers.forEach { it() }
        live.forEach { it() }
        tabChips.forEachIndexed { j, c -> styleChip(c, j == i) }
    }

    private fun thumbBmp(t: AeroTheme): Bitmap? = if (t.bgMode == 3) Imaging.load(this, t.bgUri, 360) else null

    private fun tabThemes() {
        val activeId = ThemeStore.active(this).id
        val c = card()
        c.addView(heading("Твої теми"))
        c.addView(caption("Торкнись теми, щоб відкрити її в редакторі. Крапка в куті — активна тема браузера."))
        val grid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp >= 720) 3 else 2 }
        ThemeStore.all(this).forEach { th ->
            val v = ThumbView(this, th, th.id == saved.id, th.id == activeId, thumbBmp(th))
            v.setOnClickListener { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); openTheme(th) }
            val g = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f)).apply {
                width = 0; height = dp(92); setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(v, g)
        }
        c.addView(grid)
        addCard(c)

        if (ThemeStore.custom(this).isEmpty()) {
            val e = card()
            e.addView(heading("Тут буде твоя тема"))
            e.addView(caption("Змінюй будь-який пресет, поки не скажеш «о, це воно» — і збережи. Так з'явиться твоя власна тема."))
            e.addView(btn("Створити тему", true) { newFromDraft() })
            addCard(e)
        }

        val a = card()
        a.addView(heading("Дії"))
        val row = LinearLayout(this)
        row.addView(btn("Нова з поточної") { newFromDraft() }, lp(WRAP, WRAP, r = 8, t = 8))
        row.addView(btn("Видалити") { deleteTheme() }, lp(WRAP, WRAP, r = 8, t = 8))
        row.addView(btn("Експорт") { exportTheme() }, lp(WRAP, WRAP, r = 8, t = 8))
        row.addView(btn("Імпорт") { importTheme() }, lp(WRAP, WRAP, r = 8, t = 8))
        row.addView(btn("Скинути все") { resetDraft() }, lp(WRAP, WRAP, t = 8))
        a.addView(hscroll(row))
        addCard(a)
    }

    private fun hsv(): FloatArray = FloatArray(3).also { Color.colorToHSV(getC(role), it) }

    private fun colorEditor(parent: LinearLayout, ids: List<Int>, names: List<String>) {
        if (role !in ids) role = ids[0]
        val chipsRow = LinearLayout(this)
        val chips = mutableListOf<TextView>()
        ids.forEachIndexed { k, id ->
            val ch = chip(names[k], id == role) {
                role = id
                chips.forEachIndexed { j, c -> styleChip(c, ids[j] == role) }
                refreshers.forEach { it() }
                changed()
            }
            chips.add(ch)
            chipsRow.addView(ch, lp(WRAP, WRAP, r = 8, t = 4))
        }
        parent.addView(hscroll(chipsRow))

        val info = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(2)) }
        val sw = View(this)
        val swBg = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), Color.argb(90, 128, 128, 140)) }
        sw.background = swBg
        val txt = tv("", 12f, 1, false, true)
        info.addView(sw, lp(dp(56), dp(56), r = 14))
        info.addView(txt)
        parent.addView(info)
        val upd = {
            val col = getC(role)
            swBg.setColor(col)
            txt.text = "RGB ${Color.red(col)}, ${Color.green(col)}, ${Color.blue(col)}\n${hslText(col)}"
        }
        refreshers.add(upd)
        live.add(upd)

        parent.addView(seek("Відтінок", 0, 360, "°", { hsv()[0].toInt() }) { v ->
            val h = hsv(); h[0] = v.toFloat(); setC(role, Color.HSVToColor(h))
        })
        parent.addView(seek("Насиченість", 0, 100, "%", { (hsv()[1] * 100).toInt() }) { v ->
            val h = hsv(); h[1] = v / 100f; setC(role, Color.HSVToColor(h))
        })
        parent.addView(seek("Яскравість", 0, 100, "%", { (hsv()[2] * 100).toInt() }) { v ->
            val h = hsv(); h[2] = v / 100f; setC(role, Color.HSVToColor(h))
        })

        val hex = EditText(this).apply {
            hint = "#RRGGBB"
            setSingleLine()
            typeface = Typeface.MONOSPACE
            imeOptions = EditorInfo.IME_ACTION_DONE
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            filters = arrayOf(InputFilter.LengthFilter(9))
            setOnEditorActionListener { _, _, _ -> applyHex(); clearFocus(); false }
        }
        reg {
            hex.setTextColor(pal.ink)
            hex.setHintTextColor(pal.muted)
            hex.backgroundTintList = ColorStateList.valueOf(pal.acc)
        }
        hexField = hex
        parent.addView(hex, lp(MATCH, WRAP, t = 6))
        val setHex = { if (!hex.hasFocus()) hex.setText(hexOf(getC(role))) }
        refreshers.add(setHex)
        live.add(setHex)
    }

    private fun tabColors() {
        val c = card()
        c.addView(heading("Палітра"))
        c.addView(caption("Обери роль і змінюй її колір повзунками або HEX."))
        colorEditor(c, listOf(0, 1, 2, 3, 4), baseRoles)
        addCard(c)

        val h = card()
        h.addView(heading("Гармонії акценту"))
        h.addView(caption("Сусідні відтінки, протилежний, світліший і темніший. Торкнись — і колір піде у вибрану роль."))
        val row = LinearLayout(this)
        harmony().forEach { col ->
            val v = View(this)
            v.background = GradientDrawable().apply { setColor(col); shape = GradientDrawable.OVAL; setStroke(dp(1), Color.argb(90, 128, 128, 140)) }
            v.setOnClickListener { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); pushUndo(); setC(role, col); refreshAll() }
            row.addView(v, lp(dp(46), dp(46), r = 12, t = 4))
        }
        h.addView(hscroll(row))
        addCard(h)

        val w = card()
        val msg = tv("", 13f, 0)
        w.addView(heading("Контрастність"))
        w.addView(msg)
        val upd = {
            val issues = mutableListOf<String>()
            val a = contrast(draft.textPrimary, ThemeEngine.surfaceColor(draft).withAlpha(255))
            val b = contrast(draft.textPrimary, draft.background)
            val s = contrast(draft.textSecondary, draft.surface)
            if (a < 4.5) issues.add("текст / поверхня ${"%.1f".format(a)}:1")
            if (b < 4.5) issues.add("текст / фон ${"%.1f".format(b)}:1")
            if (s < 3.0) issues.add("другорядний / поверхня ${"%.1f".format(s)}:1")
            if (issues.isEmpty()) {
                msg.setTextColor(okColor()); msg.text = "Читається чудово."
            } else {
                msg.setTextColor(warnColor())
                msg.text = "Низький контраст: " + issues.joinToString("; ") +
                    ". Бажано ≥ 4.5:1. Спробуй змінити яскравість тексту або поверхні."
            }
        }
        refreshers.add(upd)
        live.add(upd)
        addCard(w)
    }

    private fun harmony(): List<Int> {
        val h = FloatArray(3)
        Color.colorToHSV(draft.accent, h)
        fun hv(dh: Float, s: Float, v: Float) =
            Color.HSVToColor(floatArrayOf((h[0] + dh + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))
        return listOf(
            hv(30f, h[1], h[2]), hv(-30f, h[1], h[2]), hv(180f, h[1], h[2]),
            hv(0f, h[1] * 0.45f, h[2] + 0.25f), hv(0f, h[1], h[2] * 0.6f)
        )
    }

    private fun tabGlass() {
        val c = card()
        c.addView(heading("Скло — серце Aero"))
        c.addView(caption("Діє на адресний рядок, картки, панелі й діалоги. Цей редактор теж зроблений зі скла твоєї теми."))
        c.addView(seek("Непрозорість скла", 0, 100, "%", { draft.glassAlpha }) { draft = draft.copy(glassAlpha = it) })
        c.addView(seek("Розмиття фону за склом", 0, 40, " dp", { draft.blur }) { draft = draft.copy(blur = it) })
        c.addView(seek("Тонування акцентом", 0, 40, "%", { draft.tint }) { draft = draft.copy(tint = it) })
        c.addView(seek("Рамка", 0, 100, "%", { draft.borderAlpha }) { draft = draft.copy(borderAlpha = it) })
        c.addView(seek("Верхній відблиск", 0, 100, "%", { draft.highlight }) { draft = draft.copy(highlight = it) })
        c.addView(seek("Тінь (0 — немає, 3 — виразна)", 0, 3, "", { draft.shadow }) { draft = draft.copy(shadow = it) })
        addCard(c)
        val n = card()
        n.addView(caption("Розмиття справжнє (GPU, RenderEffect, Android 12+). Воно розмиває фон теми за панеллю — світлові плями, градієнт чи твоє фото, — але не вміст сайту, який відкрито."))
        addCard(n)
    }

    private fun tabShape() {
        val g = card()
        g.addView(heading("Готові профілі"))
        val row = LinearLayout(this)
        val presets = listOf(
            "Компактно" to intArrayOf(14, 8, 40, 4), "Збалансовано" to intArrayOf(20, 12, 48, 3),
            "Просторо" to intArrayOf(24, 20, 56, 2), "Заокруглено" to intArrayOf(32, 12, 52, 3),
            "Гостро" to intArrayOf(4, 10, 44, 3)
        )
        presets.forEach { (n, v) ->
            row.addView(chip(n, false) {
                pushUndo()
                draft = draft.copy(radius = v[0], gap = v[1], barH = v[2], cols = v[3])
                refreshAll()
            }, lp(WRAP, WRAP, r = 8, t = 6))
        }
        g.addView(hscroll(row))
        addCard(g)

        val c = card()
        c.addView(heading("Геометрія"))
        c.addView(seek("Скруглення", 0, 40, " dp", { draft.radius }) { draft = draft.copy(radius = it) })
        c.addView(seek("Проміжки", 4, 28, " dp", { draft.gap }) { draft = draft.copy(gap = it) })
        c.addView(seek("Висота адресного рядка", 36, 64, " dp", { draft.barH }) { draft = draft.copy(barH = it) })
        c.addView(seek("Колонок на стартовій", 2, 4, "", { draft.cols }) { draft = draft.copy(cols = it) })
        addCard(c)
    }

    private fun tabText() {
        val c = card()
        c.addView(heading("Голос браузера"))
        c.addView(caption("Шрифт"))
        c.addView(choice(FONT_NAMES, { draft.font }) { draft = draft.copy(font = it); true })
        c.addView(caption("Товщина заголовків"))
        c.addView(choice(listOf("Звичайна", "Середня", "Жирна"), { draft.weight }) { draft = draft.copy(weight = it); true })
        c.addView(seek("Масштаб тексту", 80, 130, "%", { draft.textScale }) { draft = draft.copy(textScale = it) })
        addCard(c)
        addCard(card().apply { addView(caption("Лише системні шрифти — вони є на кожному пристрої, тож тема завжди відновиться правильно.")) })
    }

    private fun tabBackground() {
        val c = card()
        c.addView(heading("Атмосфера"))
        c.addView(choice(listOf("Однотонний", "Лінійний", "Радіальний", "Зображення"), { draft.bgMode }, true) { i ->
            if (i == 3 && draft.bgUri == null) {
                pickImage(); false
            } else {
                var d = draft.copy(bgMode = i)
                if (i in 1..2 && d.stops.size < 2) d = d.copy(stops = listOf(d.background, blend(d.background, d.accent, 0.35f)))
                draft = d
                true
            }
        })
        c.addView(seek("Світлові плями", 0, 100, "%", { draft.orbs }) { draft = draft.copy(orbs = it) })
        addCard(c)

        when (draft.bgMode) {
            0 -> addCard(card().apply { addView(caption("Однотонний фон бере колір «Фон» з вкладки «Колір».")) })
            1, 2 -> {
                val g = card()
                g.addView(heading("Градієнт"))
                if (draft.bgMode == 1) g.addView(seek("Напрямок", 0, 360, "°", { draft.angle }) { draft = draft.copy(angle = it) })
                val ids = draft.stops.indices.map { 10 + it }
                if (role !in ids) role = ids[0]
                colorEditor(g, ids, ids.map { "Точка ${it - 9}" })
                val row = LinearLayout(this)
                row.addView(btn("+ точка") {
                    if (draft.stops.size < 4) {
                        pushUndo()
                        draft = draft.copy(stops = draft.stops + blend(draft.stops.last(), draft.accent, 0.4f))
                        role = 10 + draft.stops.size - 1
                        refreshAll()
                    } else toast("Максимум 4 точки")
                }, lp(WRAP, WRAP, r = 8, t = 10))
                row.addView(btn("− точка") {
                    if (draft.stops.size > 2) {
                        pushUndo()
                        val k = (role - 10).coerceIn(0, draft.stops.size - 1)
                        draft = draft.copy(stops = draft.stops.filterIndexed { i, _ -> i != k })
                        role = 10
                        refreshAll()
                    } else toast("Потрібно щонайменше 2 точки")
                }, lp(WRAP, WRAP, t = 10))
                g.addView(row)
                addCard(g)
            }
            else -> {
                val g = card()
                g.addView(heading("Твоє фото"))
                if (bmpFor(draft) == null) {
                    g.addView(tv("Зображення недоступне — показано однотонний фон. Обери інше.", 13f, 0).apply {
                        setPadding(0, dp(4), 0, dp(4)); reg { setTextColor(warnColor()) }
                    })
                }
                g.addView(seek("Затемнення", 0, 80, "%", { draft.dim }) { draft = draft.copy(dim = it) })
                val row = LinearLayout(this)
                row.addView(btn("Замінити") { pickImage() }, lp(WRAP, WRAP, r = 8, t = 10))
                row.addView(btn("Видалити фон") {
                    pushUndo()
                    draft = draft.copy(bgMode = 0, bgUri = null)
                    refreshAll()
                }, lp(WRAP, WRAP, t = 10))
                g.addView(row)
                addCard(g)
            }
        }
    }

    private fun tabAnim() {
        val c = card()
        c.addView(heading("Рух"))
        c.addView(caption("Характер"))
        c.addView(choice(listOf("Вимкнено", "Стримано", "Виразно"), { draft.anim }) { draft = draft.copy(anim = it); true })
        c.addView(seek("Тривалість", 100, 600, " мс", { draft.animMs }) { draft = draft.copy(animMs = it) })
        c.addView(btn("Показати анімацію", true) { preview.play() }, lp(MATCH, WRAP, t = 12))
        addCard(c)
        addCard(card().apply { addView(caption("Коли рух увімкнено, фон редактора повільно дихає, а прев'ю з'являється з анімацією. Якщо в системі вимкнено анімації — усе завмирає саме.")) })
    }

    // ═════ Стан ═════

    private fun pushUndo() {
        undoStack.addLast(draft)
        if (undoStack.size > 50) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(draft)
        draft = undoStack.removeLast()
        refreshAll()
    }

    private fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(draft)
        draft = redoStack.removeLast()
        refreshAll()
    }

    private fun bmpFor(t: AeroTheme): Bitmap? {
        if (t.bgMode != 3) return null
        val u = t.bgUri ?: return null
        if (u != cKey) { cKey = u; cBmp = Imaging.load(this, u, 1600) }
        return cBmp
    }

    private fun syncPreview() {
        preview.t = draft
        preview.bmp = bmpFor(draft)
        preview.invalidate()
    }

    @Suppress("DEPRECATION")
    private fun applyBars() {
        window.statusBarColor = pal.base
        window.navigationBarColor = pal.base
        val light = lum(pal.base) > 0.5
        val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (light) mask else 0, mask)
    }

    private fun updateAmbient() {
        val scale = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        val on = draft.anim > 0 && scale > 0f
        if (on && ambient == null) {
            ambient = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
                duration = 22000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - lastAmb >= 45) {
                        lastAmb = now
                        rootBg.phase = it.animatedValue as Float
                        rootBg.invalidateSelf()
                        glassViews.forEach { g -> g.invalidate() }
                    }
                }
                start()
            }
        } else if (!on && ambient != null) {
            ambient?.cancel()
            ambient = null
        }
    }

    private fun changed() {
        pal = computePal()
        themedStatic.forEach { it() }
        themed.forEach { it() }
        syncPreview()
        rootBg.t = draft
        rootBg.bmp = bmpFor(draft)
        rootBg.invalidateSelf()
        glassViews.forEach { it.invalidate() }
        nameView.text = draft.name
        dirtyDot.visibility = if (draft != saved) View.VISIBLE else View.GONE
        live.forEach { it() }
        applyBars()
        updateAmbient()
    }

    private fun refreshAll() {
        showTab(tab)
        changed()
    }

    private fun applyHex() {
        val raw = hexField?.text?.toString()?.trim().orEmpty()
        val s = if (raw.startsWith("#")) raw else "#$raw"
        try {
            val col = Color.parseColor(s) or argb(0xFF000000)
            if (col != getC(role)) { pushUndo(); setC(role, col); refreshAll() }
        } catch (e: IllegalArgumentException) {
            toast("Некоректний HEX")
        }
    }

    private fun resetCat(i: Int) {
        val s = saved
        pushUndo()
        draft = when (i) {
            1 -> draft.copy(background = s.background, surface = s.surface, textPrimary = s.textPrimary, textSecondary = s.textSecondary, accent = s.accent)
            2 -> draft.copy(glassAlpha = s.glassAlpha, tint = s.tint, borderAlpha = s.borderAlpha, highlight = s.highlight, shadow = s.shadow, blur = s.blur)
            3 -> draft.copy(radius = s.radius, gap = s.gap, barH = s.barH, cols = s.cols)
            4 -> draft.copy(font = s.font, textScale = s.textScale, weight = s.weight)
            5 -> draft.copy(bgMode = s.bgMode, stops = s.stops, angle = s.angle, bgUri = s.bgUri, dim = s.dim, orbs = s.orbs)
            6 -> draft.copy(anim = s.anim, animMs = s.animMs)
            else -> draft
        }
        refreshAll()
    }

    // ═════ Особливі режими ═════

    /** Тема на весь екран: торкнись, щоб перемкнути Старт → Вкладки → Діалог. Для демонстрації. */
    private fun showcase() {
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val pv = PreviewView(this)
        pv.t = draft
        pv.bmp = bmpFor(draft)
        pv.corner = 0f
        var m = 0
        pv.setOnClickListener {
            m = (m + 1) % 3
            pv.mode = m
            pv.play()
            pv.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        d.setContentView(pv)
        d.show()
        pv.play()
        toast("Торкнись екрана, щоб перемкнути. Назад — вихід")
    }

    /** Довге натискання на назву теми: що всередині (для цікавих). */
    private fun internals() {
        val json = ThemeStore.raw(draft)
        val params = AeroTheme::class.java.declaredFields.count { !java.lang.reflect.Modifier.isStatic(it.modifiers) }
        val a = contrast(draft.textPrimary, draft.surface)
        val grade = if (a >= 7.0) "AAA" else if (a >= 4.5) "AA" else "нижче AA"
        val msg = "Тема: ${draft.name}\n" +
            "Параметрів у моделі: $params\n" +
            "Формат: v${draft.version}, JSON ${json.toByteArray().size} байт\n" +
            "Контраст текст/поверхня: ${"%.2f".format(a)}:1 (WCAG $grade)\n" +
            "Фон: ${BG_NAMES[draft.bgMode.coerceIn(0, 3)]}\n" +
            "Рендер: Canvas, без сторонніх бібліотек\n" +
            "Розмиття: RenderEffect (GPU), ${draft.blur} dp\n" +
            "Історія змін: ${undoStack.size} кроків\n\n" + json
        val t = TextView(this).apply {
            text = msg; textSize = 12f; typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        AlertDialog.Builder(this).setTitle("Під капотом")
            .setView(ScrollView(this).apply { addView(t) })
            .setPositiveButton("Закрити", null).show()
    }

    // ═════ Дії ═════

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(i, REQ_IMG) } catch (e: Exception) { toast("Не вдалося відкрити вибір зображення") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMG || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
        if (Imaging.load(this, u.toString(), 1600) == null) { toast("Не вдалося відкрити зображення"); return }
        pushUndo()
        draft = draft.copy(bgMode = 3, bgUri = u.toString())
        cKey = null
        refreshAll()
        preview.play()
    }

    private fun openTheme(t: AeroTheme) {
        if (t.id == saved.id) return
        val go = {
            saved = t; draft = t
            undoStack.clear(); redoStack.clear()
            role = 0
            refreshAll()
            preview.play()
        }
        if (draft != saved) confirm("Незбережені зміни", "Відкинути зміни та відкрити іншу тему?") { go() } else go()
    }

    private fun uniqueName(base: String): String {
        val names = ThemeStore.all(this).map { it.name }.toSet()
        if (base !in names) return base
        var i = 2
        while ("$base $i" in names) i++
        return "$base $i"
    }

    private fun save() {
        var t = draft.copy(modified = System.currentTimeMillis())
        if (t.preset) { // пресети не перезаписуються — створюємо копію
            t = t.copy(id = UUID.randomUUID().toString(), name = uniqueName(t.name + " (копія)"), preset = false)
        }
        if (ThemeStore.upsert(this, t)) {
            ThemeEngine.apply(this, t)
            saved = t; draft = t
            undoStack.clear(); redoStack.clear()
            refreshAll()
            preview.play()
            nameView.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            toast("Збережено та застосовано")
        } else toast("Не вдалося зберегти")
    }

    private fun newFromDraft() {
        input("Назви свою тему", uniqueName(draft.name + " (копія)"), false, "Створити") { name ->
            val t = draft.copy(
                id = UUID.randomUUID().toString(),
                name = uniqueName(name.trim().ifBlank { "Нова тема" }.take(40)),
                preset = false,
                modified = System.currentTimeMillis()
            )
            if (ThemeStore.upsert(this, t)) {
                saved = t; draft = t
                undoStack.clear(); redoStack.clear()
                refreshAll()
                toast("Тему створено")
            } else toast("Не вдалося створити")
        }
    }

    private fun deleteTheme() {
        if (saved.preset) { toast("Системні пресети видаляти не можна"); return }
        val isActive = ThemeStore.active(this).id == saved.id
        val msg = "Видалити «${saved.name}»?" + if (isActive) "\nЦя тема активна — буде застосовано Arctic Glass." else ""
        confirm("Видалення теми", msg) {
            if (ThemeStore.remove(this, saved.id)) {
                if (isActive) ThemeEngine.apply(this, ThemeStore.presets[0])
                saved = ThemeStore.active(this); draft = saved
                undoStack.clear(); redoStack.clear()
                refreshAll()
                toast("Видалено")
            } else toast("Не вдалося видалити")
        }
    }

    private fun exportTheme() {
        input("Експорт теми (JSON)", ThemeStore.toJson(draft), true, "Копіювати") { text ->
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("aero-theme", text))
            toast("Скопійовано в буфер")
        }
    }

    private fun importTheme() {
        input("Імпорт теми: встав JSON", "", true, "Імпортувати") { text ->
            val t = ThemeStore.parse(text.trim())
            if (t == null) {
                toast("Некоректний або несумісний JSON")
            } else {
                val n = t.copy(name = uniqueName(t.name), modified = System.currentTimeMillis())
                if (ThemeStore.upsert(this, n)) {
                    saved = n; draft = n
                    undoStack.clear(); redoStack.clear()
                    refreshAll()
                    preview.play()
                    toast("Тему імпортовано")
                } else toast("Не вдалося зберегти імпорт")
            }
        }
    }

    private fun resetDraft() {
        if (draft == saved) return
        confirm("Скинути всі зміни", "Повернути збережений вигляд теми?") {
            pushUndo()
            draft = saved
            refreshAll()
        }
    }

    // ═════ Діалоги ═════

    private fun confirm(title: String, msg: String, onOk: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setNegativeButton("Скасувати", null)
            .setPositiveButton("Так") { _, _ -> onOk() }.show()
    }

    private fun input(title: String, initial: String, multiline: Boolean, ok: String, onOk: (String) -> Unit) {
        val e = EditText(this).apply {
            setText(initial)
            if (multiline) {
                minLines = 5
                gravity = Gravity.TOP
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            } else setSingleLine()
        }
        val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(e) }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setNegativeButton("Скасувати", null)
            .setPositiveButton(ok) { _, _ -> onOk(e.text.toString()) }.show()
    }
}

