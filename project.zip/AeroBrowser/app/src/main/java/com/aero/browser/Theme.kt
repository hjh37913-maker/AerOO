package com.aero.browser

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.*
import com.google.gson.Gson
import java.util.UUID

// ═════════════════════════ Допоміжне ═════════════════════════

fun argb(v: Long): Int = v.toInt()
fun Int.withAlpha(a: Int): Int = (this and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

internal fun blend(a: Int, b: Int, r: Float): Int {
    fun ch(x: Int, y: Int) = (x + (y - x) * r).toInt().coerceIn(0, 255)
    return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
}

internal fun lum(c: Int): Double {
    fun f(v: Int): Double {
        val s = v / 255.0
        return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }
    return 0.2126 * f(Color.red(c)) + 0.7152 * f(Color.green(c)) + 0.0722 * f(Color.blue(c))
}

internal fun contrast(a: Int, b: Int): Double {
    val x = lum(a)
    val y = lum(b)
    return (maxOf(x, y) + 0.05) / (minOf(x, y) + 0.05)
}

internal fun onColor(c: Int): Int = if (lum(c) > 0.4) argb(0xFF0B1220) else Color.WHITE
internal fun hexOf(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

internal fun avgStops(s: List<Int>, fb: Int): Int {
    if (s.isEmpty()) return fb
    var r = 0; var g = 0; var b = 0
    s.forEach { r += Color.red(it); g += Color.green(it); b += Color.blue(it) }
    return Color.rgb(r / s.size, g / s.size, b / s.size)
}

internal fun hslText(c: Int): String {
    val r = Color.red(c) / 255f
    val g = Color.green(c) / 255f
    val b = Color.blue(c) / 255f
    val mx = maxOf(r, g, b)
    val mn = minOf(r, g, b)
    val l = (mx + mn) / 2f
    val d = mx - mn
    var h = 0f
    var s = 0f
    if (d > 0f) {
        s = d / (1f - Math.abs(2f * l - 1f)).coerceAtLeast(0.0001f)
        h = if (mx == r) ((g - b) / d) % 6f else if (mx == g) (b - r) / d + 2f else (r - g) / d + 4f
        h *= 60f
        if (h < 0f) h += 360f
    }
    return "HSL ${h.toInt()}°, ${(s * 100).toInt()}%, ${(l * 100).toInt()}%"
}

val FONT_FAMILIES = listOf("sans-serif", "serif", "monospace", "sans-serif-condensed")
val FONT_NAMES = listOf("Системний", "Серифний", "Моно", "Вузький")
internal val CARD_NAMES = listOf("Пошук", "Пошта", "Карти", "Новини", "Відео", "Музика", "Диск", "Ще")
internal val BG_NAMES = listOf("однотонний", "лінійний градієнт", "радіальний градієнт", "зображення")

// ═════════════════════════ Модель теми ═════════════════════════
// Усі поля мають значення за замовчуванням -> Gson безпечно читає старі/неповні JSON.

data class AeroTheme(
    val id: String = "custom",
    val name: String = "Тема",
    val dark: Boolean = false,
    val preset: Boolean = false,
    val version: Int = 1,
    val modified: Long = 0L,
    // кольори
    val background: Int = argb(0xFFEAF2FA),
    val surface: Int = argb(0xFFFFFFFF),
    val textPrimary: Int = argb(0xFF0F1B2D),
    val textSecondary: Int = argb(0xFF5B6B7F),
    val accent: Int = argb(0xFF1F6FEB),
    // фон: 0 однотонний, 1 лінійний градієнт, 2 радіальний, 3 зображення
    val bgMode: Int = 0,
    val stops: List<Int> = emptyList(),
    val angle: Int = 120,
    val bgUri: String? = null,
    val dim: Int = 0,
    val orbs: Int = 50,   // світлові плями на фоні, 0..100
    // скло
    val glassAlpha: Int = 60,
    val tint: Int = 0,
    val borderAlpha: Int = 30,
    val highlight: Int = 40,
    val shadow: Int = 1,
    val blur: Int = 18,   // розмиття фону за склом, dp (0..40)
    // форми
    val radius: Int = 20,
    val gap: Int = 12,
    val barH: Int = 48,
    val cols: Int = 3,
    // типографіка
    val font: Int = 0,
    val textScale: Int = 100,
    val weight: Int = 1,
    // анімації: 0 вимк., 1 стримано, 2 виразно
    val anim: Int = 1,
    val animMs: Int = 260
)


// ═════════════════════════ Сховище ═════════════════════════

object ThemeStore {
    const val VERSION = 1
    private val gson = Gson()
    private fun sp(c: Context) = c.getSharedPreferences("aero_themes", Context.MODE_PRIVATE)

    val presets: List<AeroTheme> = listOf(
        // Головна тема: справжнє скляне розмиття на живому небесному фоні
        AeroTheme(
            id = "preset_aeroglass", name = "Aero Glass", dark = false, preset = true,
            background = argb(0xFFDCEBFF), surface = argb(0xFFFFFFFF),
            textPrimary = argb(0xFF0B1220), textSecondary = argb(0xFF44526B), accent = argb(0xFF2457F5),
            bgMode = 1, stops = listOf(argb(0xFF9EC5FF), argb(0xFFE3EEFF), argb(0xFF9FE8D8)), angle = 125,
            glassAlpha = 20, tint = 10, borderAlpha = 55, highlight = 100, shadow = 1, blur = 40, orbs = 100,
            radius = 22, gap = 12, barH = 50, cols = 4, font = 0, weight = 1, anim = 1, animMs = 260
        ),
        AeroTheme(
            id = "preset_aeroglass_night", name = "Aero Glass Night", dark = true, preset = true,
            background = argb(0xFF0A1024), surface = argb(0xFF1B2547),
            textPrimary = argb(0xFFF1F5FF), textSecondary = argb(0xFFA3B1D6), accent = argb(0xFF7C9BFF),
            bgMode = 2, stops = listOf(argb(0xFF1B2F6B), argb(0xFF070B18)),
            glassAlpha = 18, tint = 16, borderAlpha = 50, highlight = 90, shadow = 1, blur = 40, orbs = 100,
            radius = 22, gap = 12, barH = 50, cols = 4, font = 0, weight = 1, anim = 1, animMs = 260
        ),
        // Мінімалістичні теми: плоский фон, один акцент, тонкі лінії
        AeroTheme(
            id = "preset_studio", name = "Studio", dark = false, preset = true,
            background = argb(0xFFF4F5F7), surface = argb(0xFFFFFFFF),
            textPrimary = argb(0xFF101318), textSecondary = argb(0xFF6B7280), accent = argb(0xFF2457F5),
            bgMode = 0,
            glassAlpha = 100, tint = 0, borderAlpha = 10, highlight = 0, shadow = 0, blur = 0, orbs = 0,
            radius = 14, gap = 12, barH = 46, cols = 4, font = 0, weight = 1, anim = 1, animMs = 220
        ),
        AeroTheme(
            id = "preset_studio_dark", name = "Studio Dark", dark = true, preset = true,
            background = argb(0xFF0E0F11), surface = argb(0xFF17191D),
            textPrimary = argb(0xFFF2F3F5), textSecondary = argb(0xFF8B919B), accent = argb(0xFF7C9BFF),
            bgMode = 0,
            glassAlpha = 100, tint = 0, borderAlpha = 10, highlight = 0, shadow = 0, blur = 0, orbs = 0,
            radius = 14, gap = 12, barH = 46, cols = 4, font = 0, weight = 1, anim = 1, animMs = 220
        ),
        AeroTheme(
            id = "preset_arctic", name = "Arctic Glass", dark = false, preset = true,
            background = argb(0xFFEAF2FA), surface = argb(0xFFFFFFFF),
            textPrimary = argb(0xFF0F1B2D), textSecondary = argb(0xFF5B6B7F), accent = argb(0xFF1F6FEB),
            bgMode = 1, stops = listOf(argb(0xFFEAF2FA), argb(0xFFCFE2F6)), angle = 120,
            glassAlpha = 55, tint = 6, borderAlpha = 28, highlight = 60, shadow = 1, blur = 22, orbs = 55,
            radius = 22, gap = 12, barH = 48, cols = 3, font = 0, weight = 1, anim = 1, animMs = 260
        ),
        AeroTheme(
            id = "preset_midnight", name = "Midnight", dark = true, preset = true,
            background = argb(0xFF070B14), surface = argb(0xFF121A2B),
            textPrimary = argb(0xFFE8EEF9), textSecondary = argb(0xFF93A1B8), accent = argb(0xFF4C8DFF),
            bgMode = 2, stops = listOf(argb(0xFF132244), argb(0xFF05070D)),
            glassAlpha = 45, tint = 10, borderAlpha = 22, highlight = 25, shadow = 2, blur = 28, orbs = 70,
            radius = 20, gap = 12, barH = 48, cols = 3, font = 0, weight = 1, anim = 1, animMs = 280
        ),
        AeroTheme(
            id = "preset_pearl", name = "Pearl", dark = false, preset = true,
            background = argb(0xFFF6F1EA), surface = argb(0xFFFFFCF7),
            textPrimary = argb(0xFF2B2420), textSecondary = argb(0xFF7A6E64), accent = argb(0xFFB9774B),
            bgMode = 1, stops = listOf(argb(0xFFF6F1EA), argb(0xFFEADFCF)), angle = 150,
            glassAlpha = 72, tint = 4, borderAlpha = 24, highlight = 70, shadow = 1, blur = 14, orbs = 40,
            radius = 26, gap = 16, barH = 52, cols = 3, font = 1, weight = 0, anim = 1, animMs = 300
        ),
        AeroTheme(
            id = "preset_graphite", name = "Graphite", dark = true, preset = true,
            background = argb(0xFF1B1D21), surface = argb(0xFF2A2D33),
            textPrimary = argb(0xFFECEDEF), textSecondary = argb(0xFFA0A4AB), accent = argb(0xFF8FA3B8),
            bgMode = 0,
            glassAlpha = 85, tint = 0, borderAlpha = 18, highlight = 15, shadow = 2, blur = 8, orbs = 25,
            radius = 12, gap = 10, barH = 44, cols = 4, font = 0, weight = 2, anim = 1, animMs = 200
        ),
        AeroTheme(
            id = "preset_aurora", name = "Aurora", dark = true, preset = true,
            background = argb(0xFF0B1020), surface = argb(0xFF1A2140),
            textPrimary = argb(0xFFF0F4FF), textSecondary = argb(0xFFA9B4DA), accent = argb(0xFF3DDAB4),
            bgMode = 1, stops = listOf(argb(0xFF0B1020), argb(0xFF1B2A5A), argb(0xFF134E5E)), angle = 130,
            glassAlpha = 40, tint = 14, borderAlpha = 28, highlight = 35, shadow = 1, blur = 30, orbs = 80,
            radius = 28, gap = 14, barH = 52, cols = 3, font = 0, weight = 1, anim = 2, animMs = 360
        ),
        // Нові теми з характером
        AeroTheme(
            id = "preset_kalyna", name = "Калина", dark = true, preset = true,
            background = argb(0xFF1A0B14), surface = argb(0xFF2A1220),
            textPrimary = argb(0xFFFBEFF3), textSecondary = argb(0xFFC9A2B0), accent = argb(0xFFE8B04A),
            bgMode = 2, stops = listOf(argb(0xFF4A1230), argb(0xFF12060D)),
            glassAlpha = 48, tint = 12, borderAlpha = 30, highlight = 45, shadow = 2, blur = 26, orbs = 75,
            radius = 24, gap = 14, barH = 50, cols = 3, font = 1, weight = 1, anim = 2, animMs = 340
        ),
        AeroTheme(
            id = "preset_svitanok", name = "Світанок", dark = false, preset = true,
            background = argb(0xFFF7EDE6), surface = argb(0xFFFFFAF6),
            textPrimary = argb(0xFF3A2A33), textSecondary = argb(0xFF8A6F7A), accent = argb(0xFFE0607E),
            bgMode = 1, stops = listOf(argb(0xFFFFE3D1), argb(0xFFF3D1EA), argb(0xFFD6D9FF)), angle = 150,
            glassAlpha = 62, tint = 8, borderAlpha = 24, highlight = 70, shadow = 1, blur = 24, orbs = 65,
            radius = 28, gap = 14, barH = 52, cols = 3, font = 0, weight = 1, anim = 2, animMs = 380
        )
    )

    fun sanitize(t: AeroTheme?): AeroTheme? {
        if (t == null || t.id.isBlank() || t.version > VERSION) return null
        var stops = t.stops.take(4)
        val mode = t.bgMode.coerceIn(0, 3)
        if (mode in 1..2 && stops.size < 2) stops = listOf(t.background, blend(t.background, t.accent, 0.35f))
        val uri = t.bgUri
        return t.copy(
            name = t.name.ifBlank { "Тема" }.take(40),
            bgMode = if (mode == 3 && uri == null) 0 else mode,
            stops = stops,
            angle = t.angle.coerceIn(0, 360),
            dim = t.dim.coerceIn(0, 80),
            glassAlpha = t.glassAlpha.coerceIn(0, 100),
            tint = t.tint.coerceIn(0, 40),
            borderAlpha = t.borderAlpha.coerceIn(0, 100),
            highlight = t.highlight.coerceIn(0, 100),
            shadow = t.shadow.coerceIn(0, 3),
            blur = t.blur.coerceIn(0, 40),
            orbs = t.orbs.coerceIn(0, 100),
            radius = t.radius.coerceIn(0, 40),
            gap = t.gap.coerceIn(4, 28),
            barH = t.barH.coerceIn(36, 64),
            cols = t.cols.coerceIn(2, 4),
            font = t.font.coerceIn(0, 3),
            textScale = t.textScale.coerceIn(80, 130),
            weight = t.weight.coerceIn(0, 2),
            anim = t.anim.coerceIn(0, 2),
            animMs = t.animMs.coerceIn(100, 600)
        )
    }

    fun custom(c: Context): MutableList<AeroTheme> {
        val j = sp(c).getString("custom", null) ?: return mutableListOf()
        return try {
            gson.fromJson(j, Array<AeroTheme>::class.java)
                .mapNotNull { x -> try { sanitize(x) } catch (e: Exception) { null } }
                .filter { !it.preset }.toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun all(c: Context): List<AeroTheme> = presets + custom(c)

    fun active(c: Context): AeroTheme {
        val id = sp(c).getString("active", null)
        return all(c).firstOrNull { it.id == id } ?: presets[0]
    }

    fun setActive(c: Context, id: String) { sp(c).edit().putString("active", id).apply() }

    private fun write(c: Context, l: List<AeroTheme>): Boolean =
        sp(c).edit().putString("custom", gson.toJson(l)).commit()

    fun upsert(c: Context, t: AeroTheme): Boolean {
        val l = custom(c)
        val i = l.indexOfFirst { it.id == t.id }
        if (i >= 0) l[i] = t else l.add(t)
        return write(c, l)
    }

    fun remove(c: Context, id: String): Boolean {
        val l = custom(c)
        l.removeAll { it.id == id }
        return write(c, l)
    }

    fun raw(t: AeroTheme): String = gson.toJson(t)
    fun fromRaw(s: String): AeroTheme? = try { sanitize(gson.fromJson(s, AeroTheme::class.java)) } catch (e: Exception) { null }

    /** Експорт без шляху до зображення (він прив'язаний до пристрою) і без приватних даних. */
    fun toJson(t: AeroTheme): String =
        gson.toJson(t.copy(bgUri = null, bgMode = if (t.bgMode == 3) 0 else t.bgMode))

    /** null, якщо JSON некоректний або несумісної версії. Нічого не змінює у сховищі. */
    fun parse(json: String): AeroTheme? = try {
        sanitize(gson.fromJson(json, AeroTheme::class.java))
            ?.let { it.copy(id = UUID.randomUUID().toString(), preset = false, bgUri = null, bgMode = if (it.bgMode == 3) 0 else it.bgMode) }
    } catch (e: Exception) {
        null
    }
}

// ═════════════════════════ Рушій застосування ═════════════════════════

object ThemeEngine {
    private val listeners = mutableSetOf<(AeroTheme) -> Unit>()

    fun current(c: Context): AeroTheme = ThemeStore.active(c)

    fun apply(c: Context, t: AeroTheme) {
        ThemeStore.setActive(c, t.id)
        listeners.toList().forEach { it(t) }
    }

    fun observe(l: (AeroTheme) -> Unit) { listeners.add(l) }
    fun stopObserving(l: (AeroTheme) -> Unit) { listeners.remove(l) }

    fun surfaceColor(t: AeroTheme): Int = blend(t.surface, t.accent, t.tint / 100f).withAlpha(t.glassAlpha * 255 / 100)
    fun typeface(t: AeroTheme, bold: Boolean = false): Typeface {
        val base = Typeface.create(FONT_FAMILIES[t.font.coerceIn(0, 3)], Typeface.NORMAL)
        if (!bold) return base
        return when (t.weight) { 0 -> base; 1 -> Typeface.create(base, 500, false); else -> Typeface.create(base, 700, false) }
    }
    fun durationMs(t: AeroTheme): Long = if (t.anim == 0) 0L else t.animMs.toLong()

    /** Фон для будь-якого екрана браузера: view.background = ThemeEngine.background(ctx, t) */
    fun background(c: Context, t: AeroTheme): Drawable =
        BgDrawable(t, if (t.bgMode == 3) Imaging.load(c, t.bgUri, 1600) else null)

    /** Напівпрозора "скляна" поверхня для адресного рядка, карток, панелей. */
    fun glassDrawable(c: Context, t: AeroTheme): GradientDrawable {
        val d = c.resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(surfaceColor(t))
            cornerRadius = t.radius * d
            setStroke(maxOf(1, d.toInt()), t.textPrimary.withAlpha(t.borderAlpha * 255 / 100))
        }
    }
}

