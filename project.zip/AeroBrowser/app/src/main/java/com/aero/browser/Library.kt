package com.aero.browser

import android.content.Context
import com.google.gson.Gson

/** Закладка або запис в історії. */
data class Mark(val title: String = "", val url: String = "", val time: Long = 0L)

/** Закладки та історія. Зберігаються лише на пристрої, у SharedPreferences. */
object Library {
    private const val MAX_HISTORY = 200
    private val gson = Gson()

    private fun sp(c: Context) = c.getSharedPreferences("aero_library", Context.MODE_PRIVATE)

    private fun read(c: Context, key: String): MutableList<Mark> {
        val j = sp(c).getString(key, null) ?: return mutableListOf()
        return try {
            gson.fromJson(j, Array<Mark>::class.java).filter { it.url.isNotBlank() }.toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun write(c: Context, key: String, l: List<Mark>) {
        sp(c).edit().putString(key, gson.toJson(l)).apply()
    }

    fun bookmarks(c: Context): List<Mark> = read(c, "bookmarks")

    fun isBookmarked(c: Context, url: String): Boolean = read(c, "bookmarks").any { it.url == url }

    /** true — закладку додано, false — прибрано. */
    fun toggleBookmark(c: Context, title: String, url: String): Boolean {
        val l = read(c, "bookmarks")
        val i = l.indexOfFirst { it.url == url }
        return if (i >= 0) {
            l.removeAt(i)
            write(c, "bookmarks", l)
            false
        } else {
            l.add(0, Mark(title.ifBlank { url }, url, System.currentTimeMillis()))
            write(c, "bookmarks", l)
            true
        }
    }

    fun removeBookmark(c: Context, url: String) {
        val l = read(c, "bookmarks")
        l.removeAll { it.url == url }
        write(c, "bookmarks", l)
    }

    fun history(c: Context): List<Mark> = read(c, "history")

    fun addHistory(c: Context, title: String, url: String) {
        if (!url.startsWith("http")) return
        val l = read(c, "history")
        val entry = Mark(title.ifBlank { url }, url, System.currentTimeMillis())
        if (l.firstOrNull()?.url == url) l[0] = entry else l.add(0, entry)
        write(c, "history", l.take(MAX_HISTORY))
    }

    fun clearHistory(c: Context) {
        sp(c).edit().remove("history").apply()
    }
}
