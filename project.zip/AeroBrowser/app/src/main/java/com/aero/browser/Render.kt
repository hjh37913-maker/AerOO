package com.aero.browser

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.*
import com.google.gson.Gson
import java.util.UUID

// ═════════════════════════ Малювання фону ═════════════════════════

class BgDrawable(var t: AeroTheme, var bmp: Bitmap? = null) : Drawable() {
    var phase = 0f        // повільний дрейф світлових плям і градієнта
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG)

    private fun colors(): IntArray =
        if (t.stops.size >= 2) t.stops.toIntArray()
        else intArrayOf(t.background, blend(t.background, t.accent, 0.3f))

    override fun draw(cv: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        cv.save()
        cv.translate(b.left.toFloat(), b.top.toFloat())
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = t.background
        val image = bmp
        if (t.bgMode == 3 && image != null) {
            val s = maxOf(w / image.width, h / image.height)
            cv.save()
            cv.clipRect(0f, 0f, w, h)
            cv.translate((w - image.width * s) / 2f, (h - image.height * s) / 2f)
            cv.scale(s, s)
            cv.drawBitmap(image, 0f, 0f, bp)
            cv.restore()
            if (t.dim > 0) {
                p.color = Color.argb(t.dim * 255 / 100, 0, 0, 0)
                cv.drawRect(0f, 0f, w, h, p)
            }
        } else if (t.bgMode == 1) {
            val cs = colors()
            val pos = FloatArray(cs.size) { it / (cs.size - 1f) }
            val drift = if (phase != 0f) Math.sin(phase.toDouble()) * 12.0 else 0.0
            val rad = Math.toRadians(t.angle + drift)
            val dx = Math.cos(rad).toFloat()
            val dy = Math.sin(rad).toFloat()
            val half = (Math.abs(w * dx) + Math.abs(h * dy)) / 2f
            val cx = w / 2f
            val cy = h / 2f
            p.shader = LinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half, cs, pos, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, h, p)
            p.shader = null
        } else if (t.bgMode == 2) {
            val cs = colors()
            val pos = FloatArray(cs.size) { it / (cs.size - 1f) }
            p.shader = RadialGradient(w / 2f, h / 3f, maxOf(w, h) * 0.9f, cs, pos, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, h, p)
            p.shader = null
        } else {
            cv.drawRect(0f, 0f, w, h, p)
        }
        if (t.orbs > 0 && !(t.bgMode == 3 && image != null)) drawOrbs(cv, w, h)
        cv.restore()
    }

    private val orbFx = floatArrayOf(0.15f, 0.88f, 0.40f)
    private val orbFy = floatArrayOf(0.12f, 0.42f, 0.90f)
    private val orbFr = floatArrayOf(0.65f, 0.55f, 0.60f)

    // М'які кольорові плями: саме вони роблять розмиття скла видимим.
    private fun drawOrbs(cv: Canvas, w: Float, h: Float) {
        val hsv = FloatArray(3)
        Color.colorToHSV(t.accent, hsv)
        val a2 = floatArrayOf((hsv[0] + 40f) % 360f, hsv[1], hsv[2])
        val a3 = floatArrayOf((hsv[0] + 320f) % 360f, hsv[1], hsv[2])
        val cols = intArrayOf(t.accent, Color.HSVToColor(a2), Color.HSVToColor(a3))
        val k = t.orbs / 100f * (if (t.dark) 0.62f else 0.5f)
        val big = maxOf(w, h)
        for (i in 0..2) {
            val cx = w * (orbFx[i] + 0.06f * Math.sin((phase + i * 2.1f).toDouble()).toFloat())
            val cy = h * (orbFy[i] + 0.05f * Math.cos((phase * 0.8f + i).toDouble()).toFloat())
            p.shader = RadialGradient(
                cx, cy, big * orbFr[i],
                cols[i].withAlpha((k * 255).toInt()), cols[i].withAlpha(0), Shader.TileMode.CLAMP
            )
            cv.drawRect(0f, 0f, w, h, p)
        }
        p.shader = null
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

object Imaging {
    fun load(c: Context, uri: String?, maxSide: Int): Bitmap? {
        if (uri == null) return null
        return try {
            val u = Uri.parse(uri)
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > maxSide || o.outHeight / s > maxSide) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (e: Throwable) {
            null // URI став недоступним — повертаємо null, без аварії
        }
    }
}


// ═════════════════════════ Живе прев'ю ═════════════════════════

class PreviewView(c: Context) : View(c) {
    var t: AeroTheme = AeroTheme()
    var bmp: Bitmap? = null
    var mode = 0
    var corner = 20f
    private var u = 1f
    private var appear = 1f
    private var animator: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bg = BgDrawable(AeroTheme(), null)
    private val shape = Path()
    private val nodes = ArrayList<RenderNode>()
    private var nodeIdx = 0
    private var tfKey = -1
    private var tfBody: Typeface = Typeface.DEFAULT
    private var tfTitle: Typeface = Typeface.DEFAULT

    private fun dp(v: Float) = v * resources.displayMetrics.density * u
    private fun sp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v * t.textScale / 100f * u, resources.displayMetrics)

    fun play() {
        animator?.cancel()
        if (t.anim == 0) { appear = 1f; invalidate(); return }
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = t.animMs.toLong()
            interpolator = if (t.anim == 2) OvershootInterpolator(1.3f) else DecelerateInterpolator()
            addUpdateListener { appear = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    private fun fonts() {
        val key = t.font * 10 + t.weight
        if (key == tfKey) return
        tfKey = key
        tfBody = ThemeEngine.typeface(t, false)
        tfTitle = ThemeEngine.typeface(t, true)
    }

    private fun fit(s: String, maxW: Float): String {
        val n = p.breakText(s, true, maxW, null)
        return if (n >= s.length) s else if (n <= 1) "" else s.take(n - 1) + "…"
    }

    private fun txt(cv: Canvas, s: String, x: Float, y: Float, color: Int, size: Float, bold: Boolean = false,
                    align: Paint.Align = Paint.Align.LEFT, maxW: Float = 0f) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
        p.typeface = if (bold) tfTitle else tfBody
        p.textSize = sp(size)
        p.textAlign = align
        cv.drawText(if (maxW > 0f) fit(s, maxW) else s, x, y + sp(size) * 0.35f, p)
        p.textAlign = Paint.Align.LEFT
    }

    private fun node(): RenderNode {
        if (nodeIdx >= nodes.size) nodes.add(RenderNode("frost"))
        return nodes[nodeIdx++]
    }

    // Скляна панель: зовнішня тінь -> справжнє розмиття фону -> тонування -> відблиск -> рамка.
    private fun panel(cv: Canvas, r: RectF, rad: Float, alpha: Int = t.glassAlpha, hot: Boolean = false, dimInside: Int = 0) {
        val rr = minOf(rad, minOf(r.width(), r.height()) / 2f)
        shape.reset()
        shape.addRoundRect(r, rr, rr, Path.Direction.CW)
        p.shader = null
        p.style = Paint.Style.FILL
        if (t.shadow > 0 && alpha > 0) {
            cv.save()
            cv.clipOutPath(shape)
            p.color = Color.BLACK
            p.setShadowLayer(dp(t.shadow * 6f), 0f, dp(t.shadow * 2.5f), 0x40000000)
            cv.drawPath(shape, p)
            p.clearShadowLayer()
            cv.restore()
        }
        if (alpha > 0 && t.blur > 0) {
            Frost.draw(cv, node(), bg, width, height, r.left, r.top, r.left, r.top, r.width(), r.height(), dp(t.blur.toFloat()), shape)
        }
        if (dimInside > 0) {
            p.color = Color.argb(dimInside, 0, 0, 0)
            cv.drawPath(shape, p)
        }
        p.color = blend(t.surface, t.accent, t.tint / 100f).withAlpha(alpha * 255 / 100)
        cv.drawPath(shape, p)
        if (alpha > 0) {
            p.shader = LinearGradient(
                r.left, r.top, r.right, r.bottom,
                Color.WHITE.withAlpha(t.highlight * 255 / 100 * 22 / 100), Color.WHITE.withAlpha(0), Shader.TileMode.CLAMP
            )
            cv.drawPath(shape, p)
            p.shader = null
        }
        p.style = Paint.Style.STROKE
        if (hot) {
            p.strokeWidth = dp(2f)
            p.color = t.accent
        } else {
            p.strokeWidth = dp(1f)
            val edge = t.textPrimary.withAlpha(t.borderAlpha * 255 / 100)
            val hi = Color.WHITE.withAlpha(t.highlight * 255 / 100 * 7 / 10)
            p.shader = LinearGradient(0f, r.top, 0f, r.bottom, hi, edge, Shader.TileMode.CLAMP)
        }
        cv.drawPath(shape, p)
        p.shader = null
        p.style = Paint.Style.FILL
    }

    private fun addressBar(cv: Canvas, w: Float, text: String): RectF {
        val pad = dp(16f)
        val bar = RectF(pad, pad, w - pad, pad + dp(t.barH.toFloat()))
        panel(cv, bar, dp(t.radius.toFloat()))
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1.6f)
        p.color = t.textSecondary
        cv.drawCircle(bar.left + dp(22f), bar.centerY() - dp(1f), dp(6f), p)
        cv.drawLine(bar.left + dp(26f), bar.centerY() + dp(3f), bar.left + dp(30f), bar.centerY() + dp(7f), p)
        p.style = Paint.Style.FILL
        txt(cv, text, bar.left + dp(42f), bar.centerY(), t.textSecondary, 14f, false, Paint.Align.LEFT, bar.width() - dp(60f))
        return bar
    }

    private fun bottomBar(cv: Canvas, w: Float, h: Float): RectF {
        val pad = dp(16f)
        val bb = RectF(pad * 2, h - pad - dp(48f), w - pad * 2, h - pad)
        panel(cv, bb, dp(t.radius.toFloat()))
        p.style = Paint.Style.FILL
        for (i in 0..3) {
            val cx = bb.left + bb.width() * (i + 0.5f) / 4f
            p.color = if (i == 0) t.accent else t.textSecondary
            cv.drawCircle(cx, bb.centerY(), dp(5f), p)
        }
        return bb
    }

    private fun startPage(cv: Canvas, w: Float, h: Float) {
        val pad = dp(16f)
        val gap = dp(t.gap.toFloat())
        val rad = dp(t.radius.toFloat())
        val bar = addressBar(cv, w, "aero.browser/start")
        val bb = bottomBar(cv, w, h)
        val headY = bar.bottom + gap + sp(12f) * 0.5f
        txt(cv, "ОБРАНІ", pad + dp(4f), headY, t.textSecondary, 11f, true)
        val gridTop = headY + dp(12f)
        val avail = bb.top - gap - gridTop
        val ch = ((avail - gap) / 2f).coerceIn(dp(36f), maxOf(dp(64f), h * 0.17f))
        val cw = (w - pad * 2 - gap * (t.cols - 1)) / t.cols
        for (i in 0 until t.cols * 2) {
            val x = pad + (i % t.cols) * (cw + gap)
            val y = gridTop + (i / t.cols) * (ch + gap)
            val r = RectF(x, y, x + cw, y + ch)
            panel(cv, r, rad)
            p.style = Paint.Style.FILL
            p.color = t.accent
            cv.drawCircle(r.centerX(), y + ch * 0.36f, minOf(dp(9f), ch * 0.17f), p)
            txt(cv, CARD_NAMES[i % CARD_NAMES.size], r.centerX(), y + ch * 0.76f, t.textPrimary, 11f, false, Paint.Align.CENTER, cw - dp(8f))
        }
    }

    private fun tabsPage(cv: Canvas, w: Float, h: Float) {
        val pad = dp(16f)
        val gap = dp(t.gap.toFloat())
        val rad = dp(t.radius.toFloat())
        val bar = addressBar(cv, w, "aero.browser")
        val bd = RectF(bar.right - dp(40f), bar.centerY() - dp(13f), bar.right - dp(12f), bar.centerY() + dp(13f))
        p.style = Paint.Style.FILL
        p.color = t.accent
        cv.drawRoundRect(bd, dp(8f), dp(8f), p)
        txt(cv, "3", bd.centerX(), bd.centerY(), onColor(t.accent), 12f, true, Paint.Align.CENTER)
        val bb = bottomBar(cv, w, h)
        val top = bar.bottom + gap
        val th = ((bb.top - gap - top - gap * 2) / 3f).coerceIn(dp(36f), maxOf(dp(64f), h * 0.14f))
        val titles = listOf("Aero — стартова", "Новини дня", "Карта міста")
        val urls = listOf("aero.browser", "news.example", "maps.example")
        for (i in 0..2) {
            val y = top + i * (th + gap)
            val r = RectF(pad, y, w - pad, y + th)
            panel(cv, r, rad, if (i == 0) minOf(100, t.glassAlpha + 15) else t.glassAlpha, i == 0)
            p.style = Paint.Style.FILL
            p.color = if (i == 0) t.accent else t.textSecondary
            cv.drawCircle(r.left + dp(22f), r.centerY(), dp(9f), p)
            txt(cv, titles[i], r.left + dp(42f), r.centerY() - sp(7f), t.textPrimary, 14f, true, Paint.Align.LEFT, r.width() - dp(84f))
            txt(cv, urls[i], r.left + dp(42f), r.centerY() + sp(9f), t.textSecondary, 11f, false, Paint.Align.LEFT, r.width() - dp(84f))
            txt(cv, "×", r.right - dp(22f), r.centerY(), t.textSecondary, 18f, false, Paint.Align.CENTER)
        }
    }

    private fun dialogPage(cv: Canvas, w: Float, h: Float) {
        startPage(cv, w, h)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb(110, 0, 0, 0)
        cv.drawRect(0f, 0f, w, h, p)
        val dw = minOf(w - dp(48f), dp(320f))
        val dh = dp(150f)
        val r = RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
        val rad = dp(t.radius + 4f)
        panel(cv, r, rad, minOf(100, t.glassAlpha + 30), false, 110)
        val ix = r.left + dp(18f)
        val iw = r.width() - dp(36f)
        txt(cv, "Закрити 3 вкладки?", ix, r.top + dp(30f), t.textPrimary, 16f, true, Paint.Align.LEFT, iw)
        txt(cv, "Незбережені дані буде втрачено.", ix, r.top + dp(56f), t.textSecondary, 13f, false, Paint.Align.LEFT, iw)
        val bh = dp(40f)
        val by = r.bottom - dp(16f) - bh
        val bw = (iw - dp(10f)) / 2f
        val b1 = RectF(ix, by, ix + bw, by + bh)
        val b2 = RectF(ix + bw + dp(10f), by, ix + iw, by + bh)
        val br = minOf(rad, bh / 2f)
        panel(cv, b1, br, 0)
        txt(cv, "Скасувати", b1.centerX(), b1.centerY(), t.textPrimary, 13f, true, Paint.Align.CENTER, bw - dp(8f))
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = t.accent
        cv.drawRoundRect(b2, br, br, p)
        txt(cv, "Закрити", b2.centerX(), b2.centerY(), onColor(t.accent), 13f, true, Paint.Align.CENTER, bw - dp(8f))
    }

    override fun onDraw(cv: Canvas) {
        val dens = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        u = minOf(w / dens / 340f, h / dens / 250f).coerceIn(0.85f, 1.9f)
        fonts()
        nodeIdx = 0
        cv.save()
        val cr = corner * dens
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, w, h), cr, cr, Path.Direction.CW) }
        cv.clipPath(clip)
        bg.t = t
        bg.bmp = bmp
        bg.setBounds(0, 0, width, height)
        bg.draw(cv)
        val a = appear
        val layer = cv.saveLayerAlpha(0f, 0f, w, h, (a.coerceIn(0f, 1f) * 255).toInt())
        if (t.anim == 2) {
            val s = 0.92f + 0.08f * a
            cv.scale(s, s, w / 2f, h / 2f)
        } else if (t.anim == 1) {
            cv.translate(0f, (1f - a) * dp(8f))
        }
        when (mode) {
            0 -> startPage(cv, w, h)
            1 -> tabsPage(cv, w, h)
            else -> dialogPage(cv, w, h)
        }
        cv.restoreToCount(layer)
        cv.restore()
    }
}

// Мініатюра теми для галереї (реальні параметри теми)
class ThumbView(c: Context, val t: AeroTheme, val selected: Boolean, val active: Boolean, bmp: Bitmap?) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bg = BgDrawable(t, bmp)
    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = dp(14f)
        cv.save()
        cv.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW) })
        bg.setBounds(0, 0, width, height)
        bg.draw(cv)
        val pr = minOf(dp(t.radius * 0.35f), dp(9f))
        p.style = Paint.Style.FILL
        p.color = ThemeEngine.surfaceColor(t)
        cv.drawRoundRect(RectF(dp(10f), dp(10f), w - dp(10f), dp(26f)), pr, pr, p)
        val cw = (w - dp(30f)) / 2f
        for (i in 0..1) {
            val x = dp(10f) + i * (cw + dp(10f))
            p.color = ThemeEngine.surfaceColor(t)
            cv.drawRoundRect(RectF(x, dp(34f), x + cw, dp(52f)), pr, pr, p)
            p.color = t.accent
            cv.drawRoundRect(RectF(x + dp(8f), dp(41f), x + dp(22f), dp(45f)), dp(2f), dp(2f), p)
        }
        p.color = t.textPrimary
        p.typeface = ThemeEngine.typeface(t, true)
        p.textSize = dp(11f)
        val n = p.breakText(t.name, true, w - dp(32f), null)
        cv.drawText(if (n >= t.name.length) t.name else t.name.take(maxOf(0, n - 1)) + "…", dp(10f), h - dp(10f), p)
        if (active) {
            p.color = t.accent
            cv.drawCircle(w - dp(14f), h - dp(14f), dp(5f), p)
        }
        cv.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(if (selected) 3f else 1f)
        p.color = if (selected) t.accent else Color.argb(90, 128, 128, 140)
        val inset = p.strokeWidth / 2f
        cv.drawRoundRect(RectF(inset, inset, w - inset, h - inset), r, r, p)
        p.style = Paint.Style.FILL
    }
}



// ═════════════════════════ Справжнє розмиття (Android 12+, GPU) ═════════════════════════

object Frost {
    /**
     * Малює розмиту копію фону всередині форми shape.
     * bgLeft/bgTop — де панель знаходиться у координатах фону; cvLeft/cvTop — де вона на полотні.
     */
    fun draw(
        cv: Canvas, node: RenderNode, bg: Drawable, bgW: Int, bgH: Int,
        bgLeft: Float, bgTop: Float, cvLeft: Float, cvTop: Float,
        w: Float, h: Float, blurPx: Float, shape: Path
    ) {
        if (!cv.isHardwareAccelerated || blurPx < 0.5f || w < 1f || h < 1f) return
        val m = (blurPx * 2f).toInt() + 2
        val nw = w.toInt() + 2 * m
        val nh = h.toInt() + 2 * m
        node.setPosition(0, 0, nw, nh)
        val rc = node.beginRecording(nw, nh)
        rc.translate(m - bgLeft, m - bgTop)
        bg.setBounds(0, 0, bgW, bgH)
        bg.draw(rc)
        node.endRecording()
        node.setRenderEffect(RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP))
        cv.save()
        cv.clipPath(shape)
        cv.translate(cvLeft - m, cvTop - m)
        cv.drawRenderNode(node)
        cv.restore()
    }
}

/**
 * Скляна панель для реального інтерфейсу: розмиває фон теми, що лежить за нею.
 * backdrop — той самий BgDrawable, що є фоном host; host — View, на якому цей фон намальовано.
 */
class GlassLayout(c: Context) : LinearLayout(c) {
    var fill = 0x33FFFFFF
    var stroke = 0x33FFFFFF
    var radiusPx = 24f
    var blurPx = 0f
    var highlight = 40
    var backdrop: BgDrawable? = null
    var host: View? = null
    private val node = RenderNode("glass")
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shape = Path()
    private val rect = RectF()
    private val loc = IntArray(2)
    private val hloc = IntArray(2)

    init { setWillNotDraw(false) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w < 2f || h < 2f) return
        val hw = resources.displayMetrics.density * 0.5f
        rect.set(hw, hw, w - hw, h - hw)
        val rr = maxOf(0f, minOf(radiusPx, minOf(w, h) / 2f) - hw)
        shape.reset()
        shape.addRoundRect(rect, rr, rr, Path.Direction.CW)
        val bd = backdrop
        val hv = host
        if (blurPx > 0.5f && bd != null && hv != null && hv.width > 0 && hv.height > 0) {
            getLocationInWindow(loc)
            hv.getLocationInWindow(hloc)
            Frost.draw(
                cv, node, bd, hv.width, hv.height,
                (loc[0] - hloc[0]).toFloat(), (loc[1] - hloc[1]).toFloat(), 0f, 0f, w, h, blurPx, shape
            )
        }
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = fill
        cv.drawPath(shape, p)
        p.shader = LinearGradient(
            0f, 0f, w, h,
            Color.WHITE.withAlpha(highlight * 255 / 100 * 22 / 100), Color.WHITE.withAlpha(0), Shader.TileMode.CLAMP
        )
        cv.drawPath(shape, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = hw * 2f
        p.shader = LinearGradient(0f, 0f, 0f, h, Color.WHITE.withAlpha(highlight * 255 / 100 * 7 / 10), stroke, Shader.TileMode.CLAMP)
        cv.drawPath(shape, p)
        p.shader = null
    }
}

// ═════════════════════════ Єдиний набір іконок (сітка 24, лінія 1.9) ═════════════════════════

class IconView(c: Context, kind0: Int) : View(c) {
    var kind: Int = kind0
        set(v) { field = v; invalidate() }

    companion object {
        const val LOCK = 8
        const val MORE = 9
        const val BACK = 0
        const val FORWARD = 1
        const val HOME = 2
        const val UNDO = 3
        const val REDO = 4
        const val SPARK = 5
        const val SEARCH = 6
        const val CLOSE = 7
    }

    var color: Int = Color.WHITE
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val path = Path()

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        p.color = color
        cv.save()
        cv.translate((width - 24f * d) / 2f, (height - 24f * d) / 2f)
        cv.scale(d, d)
        path.reset()
        when (kind) {
            BACK -> { path.moveTo(15f, 5f); path.lineTo(8f, 12f); path.lineTo(15f, 19f) }
            FORWARD -> { path.moveTo(9f, 5f); path.lineTo(16f, 12f); path.lineTo(9f, 19f) }
            HOME -> {
                path.moveTo(4f, 11f); path.lineTo(12f, 4f); path.lineTo(20f, 11f)
                path.moveTo(6f, 10f); path.lineTo(6f, 19f); path.lineTo(18f, 19f); path.lineTo(18f, 10f)
            }
            UNDO, REDO -> {
                if (kind == REDO) cv.scale(-1f, 1f, 12f, 12f)
                path.moveTo(9f, 6f); path.lineTo(5f, 10f); path.lineTo(9f, 14f)
                path.moveTo(5f, 10f); path.lineTo(13f, 10f)
                path.cubicTo(17f, 10f, 19.5f, 12.5f, 19.5f, 15f)
                path.cubicTo(19.5f, 17.5f, 17f, 20f, 13f, 20f)
            }
            SPARK -> {
                path.moveTo(12f, 3f); path.lineTo(14.2f, 9.8f); path.lineTo(21f, 12f); path.lineTo(14.2f, 14.2f)
                path.lineTo(12f, 21f); path.lineTo(9.8f, 14.2f); path.lineTo(3f, 12f); path.lineTo(9.8f, 9.8f)
                path.close()
            }
            SEARCH -> {
                path.addCircle(10.5f, 10.5f, 6f, Path.Direction.CW)
                path.moveTo(15f, 15f); path.lineTo(20f, 20f)
            }
            MORE -> {
                path.addCircle(5.5f, 12f, 0.8f, Path.Direction.CW)
                path.addCircle(12f, 12f, 0.8f, Path.Direction.CW)
                path.addCircle(18.5f, 12f, 0.8f, Path.Direction.CW)
            }
            LOCK -> {
                path.moveTo(8.5f, 11f); path.lineTo(8.5f, 8f)
                path.cubicTo(8.5f, 4.2f, 15.5f, 4.2f, 15.5f, 8f); path.lineTo(15.5f, 11f)
                path.addRoundRect(5.5f, 11f, 18.5f, 20f, 2.5f, 2.5f, Path.Direction.CW)
            }
            else -> {
                path.moveTo(6f, 6f); path.lineTo(18f, 18f)
                path.moveTo(18f, 6f); path.lineTo(6f, 18f)
            }
        }
        cv.drawPath(path, p)
        cv.restore()
    }
}
