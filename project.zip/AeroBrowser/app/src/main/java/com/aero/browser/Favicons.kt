package com.aero.browser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Іконки сайтів. Завантажуються один раз, потім беруться з пам'яті або з кешу на диску.
 * Джерело — сервіс іконок Google (запит містить лише домен сайту). Якщо мережі немає, показується літера.
 */
object Favicons {
    private val mem = HashMap<String, Bitmap>()
    private val pending = HashMap<String, MutableList<(Bitmap?) -> Unit>>()
    private val main = Handler(Looper.getMainLooper())

    private fun safe(host: String) = host.lowercase().filter { it.isLetterOrDigit() || it == '.' || it == '-' }.take(80)

    /** Результат приходить у головному потоці. */
    fun load(c: Context, host: String, done: (Bitmap?) -> Unit) {
        val key = safe(host)
        if (key.isEmpty() || !key.contains('.')) { done(null); return }
        mem[key]?.let { done(it); return }
        val waiting = pending[key]
        if (waiting != null) { waiting.add(done); return }
        pending[key] = mutableListOf(done)
        val dir = File(c.applicationContext.cacheDir, "favicons").apply { mkdirs() }
        Thread {
            val file = File(dir, "$key.png")
            var bmp: Bitmap? = null
            try {
                if (file.exists()) bmp = BitmapFactory.decodeFile(file.path)
                if (bmp == null) {
                    val u = URL("https://www.google.com/s2/favicons?sz=128&domain=" + URLEncoder.encode(key, "UTF-8"))
                    val conn = u.openConnection() as HttpURLConnection
                    conn.connectTimeout = 6000
                    conn.readTimeout = 6000
                    try {
                        if (conn.responseCode == 200) {
                            val bytes = conn.inputStream.use { it.readBytes() }
                            if (bytes.size in 1..300_000) {
                                bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                if (bmp != null) file.writeBytes(bytes)
                            }
                        }
                    } finally {
                        conn.disconnect()
                    }
                }
            } catch (e: Exception) {
                bmp = null
            }
            val result = bmp
            main.post {
                if (result != null) mem[key] = result
                pending.remove(key)?.forEach { it(result) }
            }
        }.start()
    }
}
