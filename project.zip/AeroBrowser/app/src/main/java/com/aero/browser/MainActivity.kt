package com.aero.browser

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Одна вкладка: власний WebView, заголовок і адреса. Порожня адреса означає стартову сторінку. */
class BrowserTab(val web: WebView) {
    var title: String = ""
    var url: String = ""
}

/**
 * Aero Browser — головний екран.
 * Усе, що ти бачиш (фон, скло, шрифти, кольори, рух), бере параметри з активної теми Theme Studio.
 */
class MainActivity : Activity() {

    private val MATCH = -1
    private val WRAP = -2

    private val tabs = mutableListOf<BrowserTab>()
    private var cur = 0
    private val webView: WebView get() = tabs[cur].web
    private val tab: BrowserTab get() = tabs[cur]
    private val browsing: Boolean get() = tabs.getOrNull(cur)?.url?.isNotEmpty() == true

    private var shown: AeroTheme? = null
    private var bg: BgDrawable? = null
    private val glass = mutableListOf<GlassLayout>()
    private var ambient: ValueAnimator? = null
    private var lastAmb = 0L
    private var urlField: EditText? = null
    private var progress: View? = null
    private var startPage: View? = null
    private var webHolder: FrameLayout? = null
    private val tabCounts = mutableListOf<TextView>()
    private var greetName: TextView? = null
    private var barView: View? = null
    private var leadIcon: IconView? = null
    private var clearIcon: IconView? = null
    private var currentUrl = ""
    private var favsDirty = false

    // нижня шторка (вкладки, меню, закладки, історія)
    private var sheetScrim: FrameLayout? = null
    private var sheetPanel: View? = null
    private var sheetTitle: TextView? = null
    private var sheetAction: TextView? = null
    private var sheetBody: LinearLayout? = null
    private var sheetRender: (() -> Unit)? = null

    // кольори й шрифти активної теми для динамічно створених рядків
    private var uiInk = Color.WHITE
    private var uiMuted = Color.GRAY
    private var uiAccent = Color.BLUE
    private var uiSc = 1f
    private var uiTf: Typeface = Typeface.DEFAULT
    private var uiTfB: Typeface = Typeface.DEFAULT_BOLD

    private val prefs by lazy { getSharedPreferences("aero_prefs", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun hostOf(url: String): String =
        if (url.isEmpty()) "" else (Uri.parse(url).host?.removePrefix("www.") ?: url)

    // ───────── життєвий цикл ─────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tabs.add(createTab())
        val t = ThemeEngine.current(this)
        shown = t
        setContentView(buildUi(t))
        applyBars(t)
        updateAmbient(t)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        val t = ThemeEngine.current(this)
        if (t != shown) { // тему змінили в Theme Studio
            shown = t
            rebuildUi()
        }
        ambient?.resume()
        webView.onResume()
    }

    override fun onPause() {
        ambient?.pause()
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        ambient?.cancel()
        ambient = null
        tabs.forEach {
            (it.web.parent as? ViewGroup)?.removeView(it.web)
            it.web.destroy()
        }
        tabs.clear()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            sheetScrim?.visibility == View.VISIBLE -> closeSheet()
            browsing -> goBackAction()
            tabs.size > 1 -> closeTab(cur)
            else -> super.onBackPressed()
        }
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        if (browsing) newTab(d.toString()) else navigate(d.toString())
    }

    private fun rebuildUi() {
        val t = shown ?: return
        (webView.parent as? ViewGroup)?.removeView(webView)
        setContentView(buildUi(t))
        applyBars(t)
        updateAmbient(t)
    }

    // ───────── інтерфейс ─────────

    private fun buildUi(t: AeroTheme): View {
        glass.clear()
        tabCounts.clear()
        val bgd = BgDrawable(t, if (t.bgMode == 3) Imaging.load(this, t.bgUri, 1600) else null)
        bg = bgd
        val ink = t.textPrimary
        val muted = t.textSecondary
        val tfR = ThemeEngine.typeface(t, false)
        val tfB = ThemeEngine.typeface(t, true)
        val sc = t.textScale / 100f
        uiInk = ink; uiMuted = muted; uiAccent = t.accent; uiSc = sc; uiTf = tfR; uiTfB = tfB
        val root = FrameLayout(this).apply {
            fitsSystemWindows = true
            background = bgd
        }

        fun newGlass(radiusDp: Int): GlassLayout {
            val g = GlassLayout(this)
            g.fill = ThemeEngine.surfaceColor(t)
            g.stroke = t.textPrimary.withAlpha(t.borderAlpha * 255 / 100)
            g.radiusPx = dp(radiusDp).toFloat()
            g.blurPx = dp(t.blur).toFloat()
            g.highlight = t.highlight
            g.backdrop = bgd
            g.host = root
            glass.add(g)
            return g
        }

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun tabsButton(): View {
            val count = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 11f
                typeface = tfB
                setTextColor(ink)
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setStroke(dp(2), ink)
                }
            }
            tabCounts.add(count)
            return newGlass(22).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(count, lp(dp(22), dp(22)))
                setOnClickListener {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    showTabs()
                }
            }
        }

        fun menuButton(): View = newGlass(22).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(IconView(this@MainActivity, IconView.MORE).apply { color = ink }, lp(dp(28), dp(28)))
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                showMenu()
            }
        }

        // адресний рядок: у спокої показує лише домен із замком, у фокусі — повну адресу
        val bar = newGlass(t.radius).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(8), 0)
        }
        val lead = IconView(this, IconView.SEARCH).apply { color = muted }
        leadIcon = lead
        bar.addView(lead, lp(dp(22), dp(22)))
        val clear = IconView(this, IconView.CLOSE).apply {
            color = muted
            visibility = View.GONE
        }
        clearIcon = clear
        val field = EditText(this).apply {
            background = null
            hint = "Пошук або адреса"
            setHintTextColor(muted)
            setTextColor(ink)
            typeface = tfR
            textSize = 16f * sc
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { v, _, _ ->
                navigate(v.text.toString())
                hideKeyboard(v)
                true
            }
            onFocusChangeListener = View.OnFocusChangeListener { v, focused ->
                val f = v as EditText
                if (focused) {
                    lead.kind = IconView.SEARCH
                    f.setText(currentUrl)
                    f.selectAll()
                } else {
                    showUrl(currentUrl)
                }
                clear.visibility = if (focused && f.text.isNotEmpty()) View.VISIBLE else View.GONE
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    clear.visibility = if (hasFocus() && !s.isNullOrEmpty()) View.VISIBLE else View.GONE
                }
            })
        }
        urlField = field
        clear.setOnClickListener { field.setText("") }
        bar.addView(field, lp(0, MATCH, l = 10).apply { weight = 1f })
        bar.addView(clear, lp(dp(32), dp(32)))
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = if (browsing) View.VISIBLE else View.GONE
        }
        topRow.addView(bar, lp(0, MATCH).apply { weight = 1f })
        topRow.addView(tabsButton(), lp(dp(44), dp(44), l = 8))
        topRow.addView(menuButton(), lp(dp(44), dp(44), l = 8))
        barView = topRow
        column.addView(topRow, lp(MATCH, dp(t.barH), l = 16, t = 10, r = 8))

        // індикатор завантаження
        val pb = View(this).apply {
            setBackgroundColor(t.accent)
            pivotX = 0f
            scaleX = 0f
            visibility = View.INVISIBLE
        }
        progress = pb
        column.addView(pb, lp(MATCH, dp(2), l = 16, t = 6, r = 16))

        val body = FrameLayout(this)

        // стартова сторінка: бренд, привітання, великий пошук, закладки, нещодавнє
        val entrance = mutableListOf<View>()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(dp(24), dp(20), dp(24), dp(24))
        }
        val accent2 = shiftHue(t.accent, -38f)
        val surfaceSolid = t.surface.withAlpha(255)
        val hairline = ink.withAlpha(24)

        fun sectionLabel(text: String) = TextView(this).apply {
            this.text = text
            textSize = 13f * sc
            setTextColor(muted)
            typeface = tfB
            setPadding(dp(2), dp(34), 0, dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(t.accent, accent2))
                .apply { cornerRadius = dp(9).toFloat() }
            addView(IconView(this@MainActivity, IconView.SPARK).apply { color = Color.WHITE }, FrameLayout.LayoutParams(dp(28), dp(28)))
        }
        header.addView(logo, lp(dp(28), dp(28)))
        header.addView(TextView(this).apply {
            text = "aero"
            textSize = 19f * sc
            setTextColor(ink)
            typeface = tfB
            letterSpacing = -0.01f
        }, lp(0, WRAP, l = 10).apply { weight = 1f })
        header.addView(tabsButton(), lp(dp(44), dp(44), l = 8))
        header.addView(menuButton(), lp(dp(44), dp(44), l = 8))
        page.addView(header)

        val uk = Locale("uk", "UA")
        val hello = TextView(this).apply {
            text = greeting()
            textSize = 34f * sc
            setTextColor(ink)
            typeface = Typeface.create(tfR, 300, false)
        }
        val name = TextView(this).apply {
            text = ownerName()
            textSize = 34f * sc
            setTextColor(ink)
            typeface = tfB
            setOnClickListener { renameOwner() }
        }
        greetName = name
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE, d MMMM", uk).format(Date()).replaceFirstChar { it.titlecase(uk) }
            textSize = 15f * sc
            setTextColor(muted)
            typeface = tfR
            setPadding(0, dp(10), 0, 0)
        }
        val greetCard = newGlass(30).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(22), dp(24), dp(22))
        }
        greetCard.addView(hello); greetCard.addView(name); greetCard.addView(date)
        page.addView(greetCard, lp(MATCH, WRAP, t = 28))
        entrance.add(header); entrance.add(greetCard)

        // великий пошук
        val pill = newGlass(29).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), 0, dp(16), 0)
        }
        pill.addView(IconView(this, IconView.SEARCH).apply { color = muted }, lp(dp(22), dp(22)))
        val heroField = EditText(this).apply {
            background = null
            hint = "Пошук або адреса"
            setHintTextColor(muted)
            setTextColor(ink)
            typeface = tfR
            textSize = 16.5f * sc
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { v, _, _ ->
                val q = v.text.toString()
                v.text = ""
                hideKeyboard(v)
                navigate(q)
                true
            }
        }
        pill.addView(heroField, lp(0, MATCH, l = 12).apply { weight = 1f })
        page.addView(pill, lp(MATCH, dp(58), t = 30, b = 4))
        entrance.add(pill)

        // швидкий доступ: закладки першими, далі типові сайти
        page.addView(sectionLabel("Швидкий доступ"))
        val marks = Library.bookmarks(this).take(8).map {
            Pair(it.title.ifBlank { hostOf(it.url) }, it.url)
        }
        val defaults = listOf(
            Pair("Google", "https://www.google.com"),
            Pair("YouTube", "https://www.youtube.com"),
            Pair("Вікіпедія", "https://uk.wikipedia.org"),
            Pair("GitHub", "https://github.com"),
            Pair("Claude", "https://claude.ai"),
            Pair("Telegram", "https://web.telegram.org"),
            Pair("Укрінформ", "https://www.ukrinform.ua"),
            Pair("Reddit", "https://www.reddit.com")
        )
        val favs = (marks + defaults.filter { d -> marks.none { hostOf(it.second) == hostOf(d.second) } }).take(8)
        val grid = GridLayout(this).apply {
            columnCount = 4
            clipChildren = false
        }
        favs.forEach { (n, u) ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(8), 0, dp(10))
            }
            val letter = TextView(this).apply {
                text = n.take(1).uppercase()
                gravity = Gravity.CENTER
                textSize = 20f
                typeface = tfB
                setTextColor(ink)
            }
            val icon = iconView(10)
            val badge = newGlass(17).apply {
                orientation = LinearLayout.VERTICAL
                addView(FrameLayout(this@MainActivity).apply {
                    addView(letter, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
                    addView(icon, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
                }, lp(MATCH, MATCH))
            }
            bindIcon(icon, letter, hostOf(u))
            cell.addView(badge, lp(dp(54), dp(54)))
            cell.addView(TextView(this).apply {
                text = n
                textSize = 12f * sc
                setTextColor(muted)
                typeface = tfR
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, 0)
            }, lp(WRAP, WRAP))
            cell.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                navigate(u)
            }
            cell.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().alpha(0.55f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().alpha(1f).setDuration(140).start()
                }
                false
            }
            val g = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                height = WRAP
            }
            grid.addView(cell, g)
            entrance.add(cell)
        }
        page.addView(grid)

        // нещодавно відкрите
        val recent = Library.history(this).distinctBy { hostOf(it.url) }.take(3)
        if (recent.isNotEmpty()) {
            page.addView(sectionLabel("Нещодавно"))
            val card = newGlass(20).apply { orientation = LinearLayout.VERTICAL }
            recent.forEachIndexed { i, m ->
                if (i > 0) card.addView(View(this).apply { setBackgroundColor(hairline) }, lp(MATCH, 1, l = 16))
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(13), dp(16), dp(13))
                    setOnClickListener {
                        it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        navigate(m.url)
                    }
                }
                val mono = TextView(this).apply {
                    text = hostOf(m.url).take(1).uppercase()
                    gravity = Gravity.CENTER
                    textSize = 13f
                    typeface = tfB
                    setTextColor(muted)
                }
                val ic = iconView(8)
                row.addView(FrameLayout(this).apply {
                    background = GradientDrawable().apply {
                        setColor(ink.withAlpha(14))
                        cornerRadius = dp(11).toFloat()
                    }
                    addView(mono, FrameLayout.LayoutParams(MATCH, MATCH))
                    addView(ic, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
                }, lp(dp(36), dp(36)))
                bindIcon(ic, mono, hostOf(m.url))
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                col.addView(TextView(this).apply {
                    text = m.title.ifBlank { hostOf(m.url) }
                    textSize = 15f * sc
                    setTextColor(ink)
                    typeface = tfB
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
                col.addView(TextView(this).apply {
                    text = hostOf(m.url)
                    textSize = 12.5f * sc
                    setTextColor(muted)
                    typeface = tfR
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
                row.addView(col, lp(0, WRAP, l = 14).apply { weight = 1f })
                card.addView(row, lp(MATCH, WRAP))
            }
            page.addView(card, lp(MATCH, WRAP))
            entrance.add(card)
        }

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(0, 0, 0, dp(24))
            addView(page)
            setOnScrollChangeListener { _, _, _, _, _ -> glass.forEach { it.invalidate() } }
            visibility = if (browsing) View.GONE else View.VISIBLE
        }
        startPage = scroll
        body.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        // вебсторінка на всю ширину, без рамок
        val holder = FrameLayout(this).apply {
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(t.radius).toFloat())
                }
            }
            clipToOutline = true
            visibility = if (browsing) View.VISIBLE else View.GONE
        }
        holder.addView(webView, FrameLayout.LayoutParams(MATCH, MATCH))
        webHolder = holder
        body.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            setMargins(dp(12), dp(8), dp(12), dp(12))
        })

        column.addView(body, lp(MATCH, 0).apply { weight = 1f })
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        // шторка: вкладки, меню, закладки, історія
        val scrim = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(120, 0, 0, 0))
            visibility = View.GONE
            setOnClickListener { closeSheet() }
        }
        val panel = newGlass(20).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(10))
            fill = blend(t.surface, t.accent, t.tint / 100f).withAlpha(205)
            isClickable = true
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(6), dp(6))
        }
        val title = TextView(this).apply {
            textSize = 20f * sc
            setTextColor(ink)
            typeface = tfB
        }
        val action = TextView(this).apply {
            textSize = 15f * sc
            setTextColor(t.accent)
            typeface = tfB
            setPadding(dp(10), dp(8), dp(4), dp(8))
        }
        head.addView(title, lp(0, WRAP).apply { weight = 1f })
        head.addView(action, lp(WRAP, WRAP))
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sheetScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(rows)
        }
        panel.addView(head, lp(MATCH, WRAP))
        panel.addView(sheetScroll, lp(MATCH, WRAP))
        scrim.addView(panel, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            setMargins(dp(12), dp(72), dp(12), dp(12))
        })
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        sheetScrim = scrim; sheetPanel = panel; sheetTitle = title; sheetAction = action; sheetBody = rows

        // поява елементів із легкою затримкою
        if (t.anim > 0) {
            entrance.forEachIndexed { i, v ->
                v.alpha = 0f
                v.translationY = dp(18).toFloat()
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(minOf(i, 9) * 55L)
                    .setDuration(t.animMs.toLong() + 120)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            }
        }

        showUrl(tab.url)
        updateNav()
        return root
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h in 5..11 -> "Доброго ранку,"
            h in 12..17 -> "Доброго дня,"
            h in 18..22 -> "Добрий вечір,"
            else -> "Доброї ночі,"
        }
    }

    private fun ownerName(): String = prefs.getString("owner", null)?.ifBlank { null } ?: "друже"

    private fun renameOwner() {
        val e = EditText(this).apply {
            setText(ownerName())
            setSingleLine()
            setSelection(text.length)
        }
        val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(e) }
        AlertDialog.Builder(this)
            .setTitle("Як до тебе звертатись?")
            .setView(box)
            .setNegativeButton("Скасувати", null)
            .setPositiveButton("Зберегти") { _, _ ->
                val n = e.text.toString().trim().take(24)
                prefs.edit().putString("owner", n).apply()
                greetName?.text = ownerName()
            }.show()
    }

    private fun iconView(radiusDp: Int): ImageView = ImageView(this).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        visibility = View.GONE
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(radiusDp).toFloat())
            }
        }
        clipToOutline = true
    }

    /** Підміняє літеру справжньою іконкою сайту, щойно вона завантажиться. */
    private fun bindIcon(img: ImageView, letter: View, host: String) {
        Favicons.load(this, host) { bmp ->
            if (bmp != null && !isDestroyed) {
                img.setImageBitmap(bmp)
                img.visibility = View.VISIBLE
                letter.visibility = View.GONE
            }
        }
    }

    private fun shiftHue(c: Int, d: Float): Int {
        val h = FloatArray(3)
        Color.colorToHSV(c, h)
        h[0] = (h[0] + d + 360f) % 360f
        return Color.HSVToColor(h)
    }

    private fun tileColor(url: String): Int {
        val hue = (Math.abs(hostOf(url).hashCode()) % 360).toFloat()
        return Color.HSVToColor(floatArrayOf(hue, 0.62f, 0.82f))
    }

    // ───────── шторка ─────────

    private fun showSheet(render: () -> Unit) {
        sheetRender = render
        render()
        val scrim = sheetScrim ?: return
        if (scrim.visibility != View.VISIBLE) {
            scrim.visibility = View.VISIBLE
            scrim.alpha = 0f
            scrim.animate().alpha(1f).setDuration(180).start()
            sheetPanel?.apply {
                alpha = 0f
                translationY = dp(36).toFloat()
                animate().alpha(1f).translationY(0f).setDuration(240)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
        }
        urlField?.let { if (it.hasFocus()) hideKeyboard(it) }
    }

    private fun refreshSheet() { sheetRender?.invoke() }

    private fun closeSheet() {
        sheetScrim?.visibility = View.GONE
        sheetRender = null
    }

    private fun fillSheet(title: String, actionText: String?, onAction: (() -> Unit)?, rows: List<View>) {
        sheetTitle?.text = title
        sheetAction?.let { a ->
            if (actionText == null) {
                a.visibility = View.GONE
            } else {
                a.text = actionText
                a.visibility = View.VISIBLE
                a.setOnClickListener { onAction?.invoke() }
            }
        }
        val body = sheetBody ?: return
        body.removeAllViews()
        rows.forEach { body.addView(it, lp(MATCH, WRAP)) }
    }

    private fun sheetRow(title: String, sub: String?, highlight: Boolean, onClick: () -> Unit, onRemove: (() -> Unit)?): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(10), dp(2), dp(10))
            minimumHeight = dp(52)
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                onClick()
            }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            textSize = 16f * uiSc
            setTextColor(if (highlight) uiAccent else uiInk)
            typeface = if (highlight) uiTfB else uiTf
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        if (!sub.isNullOrEmpty()) {
            col.addView(TextView(this).apply {
                text = sub
                textSize = 12.5f * uiSc
                setTextColor(uiMuted)
                typeface = uiTf
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
        row.addView(col, lp(0, WRAP).apply { weight = 1f })
        if (onRemove != null) {
            row.addView(IconView(this, IconView.CLOSE).apply {
                color = uiMuted
                setOnClickListener { onRemove() }
            }, lp(dp(40), dp(40)))
        }
        return row
    }

    private fun emptyNote(text: String): View = TextView(this).apply {
        this.text = text
        textSize = 14f * uiSc
        setTextColor(uiMuted)
        typeface = uiTf
        setPadding(dp(6), dp(14), dp(6), dp(18))
    }

    private fun showTabs() = showSheet {
        val rows = tabs.mapIndexed { i, tb ->
            sheetRow(
                tb.title.ifBlank { hostOf(tb.url).ifEmpty { "Нова вкладка" } },
                if (tb.url.isEmpty()) "Стартова сторінка" else hostOf(tb.url),
                i == cur,
                { closeSheet(); selectTab(i) },
                { closeTab(i); refreshSheet() }
            )
        }
        fillSheet("Вкладки: ${tabs.size}", "Нова вкладка", { closeSheet(); newTab(null) }, rows)
    }

    private fun showMenu() = showSheet {
        val rows = mutableListOf<View>()
        fun item(label: String, f: () -> Unit) = rows.add(sheetRow(label, null, false, { closeSheet(); f() }, null))
        item("Нова вкладка") { newTab(null) }
        if (browsing) {
            if (webView.canGoForward()) item("Вперед") { webView.goForward() }
            item("Стартова сторінка") { showStart() }
            val saved = Library.isBookmarked(this, tab.url)
            item(if (saved) "Видалити із закладок" else "Додати в закладки") { toggleBookmark() }
            item("Поділитися") { shareCurrent() }
        }
        item("Закладки") { showBookmarks() }
        item("Історія") { showHistory() }
        item("Тема оформлення") { openStudio() }
        fillSheet("Меню", null, null, rows)
    }

    private fun showBookmarks() = showSheet {
        val list = Library.bookmarks(this)
        val rows = if (list.isEmpty()) {
            listOf(emptyNote("Закладок поки немає. Відкрий сторінку й обери в меню «Додати в закладки»."))
        } else list.map { m ->
            sheetRow(
                m.title.ifBlank { hostOf(m.url) }, hostOf(m.url), false,
                { closeSheet(); navigate(m.url) },
                { Library.removeBookmark(this, m.url); favsDirty = true; refreshSheet() }
            )
        }
        fillSheet("Закладки", null, null, rows)
    }

    private fun showHistory() = showSheet {
        val list = Library.history(this).take(100)
        val rows = if (list.isEmpty()) {
            listOf(emptyNote("Історія порожня. Відкриті сторінки з'являться тут."))
        } else list.map { m ->
            sheetRow(m.title.ifBlank { hostOf(m.url) }, hostOf(m.url), false, { closeSheet(); navigate(m.url) }, null)
        }
        fillSheet(
            "Історія",
            if (list.isEmpty()) null else "Очистити",
            { Library.clearHistory(this); refreshSheet() },
            rows
        )
    }

    private fun toggleBookmark() {
        if (!browsing) return
        val title = tab.title.ifBlank { hostOf(tab.url) }
        val added = Library.toggleBookmark(this, title, tab.url)
        favsDirty = true
        Toast.makeText(this, if (added) "Додано в закладки" else "Видалено із закладок", Toast.LENGTH_SHORT).show()
    }

    private fun shareCurrent() {
        if (!browsing) return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, tab.url)
        }
        try {
            startActivity(Intent.createChooser(send, null))
        } catch (e: Exception) {
            Toast.makeText(this, "Не вдалося поділитися", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────── вкладки та навігація ─────────

    private fun createTab(): BrowserTab {
        val wv = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.safeBrowsingEnabled = true
            setBackgroundColor(Color.WHITE)
        }
        val tb = BrowserTab(wv)
        fun isCurrent() = tabs.getOrNull(cur) === tb
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val s = u.scheme ?: return false
                if (s == "http" || s == "https" || s == "about" || s == "blob") return false
                // tel:, mailto:, intent: та подібні відкриваємо лише після дотику користувача
                if (request?.hasGesture() == true) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { }
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url == null || url == "about:blank") return
                tb.url = url
                if (isCurrent()) {
                    showUrl(url)
                    showProgress(0.05f)
                    updateNav()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == "about:blank") {
                    view?.clearHistory()
                    return
                }
                if (url != null) {
                    tb.url = url
                    val ttl = view?.title.orEmpty()
                    if (ttl.isNotBlank()) tb.title = ttl
                    Library.addHistory(this@MainActivity, tb.title, url)
                }
                if (isCurrent()) {
                    url?.let { showUrl(it) }
                    showProgress(1f)
                    updateNav()
                }
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (isCurrent() && tb.url.isNotEmpty()) showProgress(newProgress / 100f)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) tb.title = title
            }
        }
        return tb
    }

    private fun newTab(url: String?) {
        tabs.add(createTab())
        selectTab(tabs.lastIndex)
        if (url != null) navigate(url)
    }

    private fun selectTab(i: Int) {
        webHolder?.removeAllViews()
        cur = i.coerceIn(0, tabs.lastIndex)
        if (favsDirty && !browsing) {
            favsDirty = false
            rebuildUi()
            return
        }
        webHolder?.let {
            (webView.parent as? ViewGroup)?.removeView(webView)
            it.addView(webView, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        progress?.visibility = View.INVISIBLE
        showUrl(tab.url)
        applyMode()
    }

    private fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        val gone = tabs.removeAt(i)
        (gone.web.parent as? ViewGroup)?.removeView(gone.web)
        gone.web.destroy()
        if (tabs.isEmpty()) tabs.add(createTab())
        val next = if (i < cur) cur - 1 else cur
        selectTab(next)
    }

    private fun applyMode() {
        barView?.visibility = if (browsing) View.VISIBLE else View.GONE
        startPage?.visibility = if (browsing) View.GONE else View.VISIBLE
        webHolder?.visibility = if (browsing) View.VISIBLE else View.GONE
        updateNav()
    }

    private fun showProgress(f: Float) {
        val pb = progress ?: return
        pb.visibility = View.VISIBLE
        pb.alpha = 1f
        pb.animate().scaleX(f.coerceIn(0f, 1f)).setDuration(120).start()
        if (f >= 1f) {
            pb.postDelayed({
                pb.visibility = View.INVISIBLE
                pb.scaleX = 0f
            }, 380)
        }
    }

    private fun navigate(raw: String) {
        val s = raw.trim()
        if (s.isEmpty()) return
        val url = when {
            s.contains("://") -> s
            s.contains(' ') || !s.contains('.') -> "https://duckduckgo.com/?q=" + Uri.encode(s)
            else -> "https://$s"
        }
        tab.url = url
        tab.title = ""
        applyMode()
        showUrl(url)
        webView.loadUrl(url)
    }

    /** Запам'ятовує адресу; поза фокусом у рядку показує лише домен, а замок — для https. */
    private fun showUrl(url: String) {
        currentUrl = url
        val f = urlField ?: return
        if (f.hasFocus()) return
        f.setText(hostOf(url))
        leadIcon?.kind = if (url.startsWith("https://")) IconView.LOCK else IconView.SEARCH
    }

    private fun showStart() {
        tab.url = ""
        tab.title = ""
        webView.loadUrl("about:blank")
        showUrl("")
        if (favsDirty) {
            favsDirty = false
            rebuildUi()
        } else {
            applyMode()
        }
    }

    private fun goBackAction() {
        if (!browsing) return
        if (webView.canGoBack()) webView.goBack() else showStart()
    }

    private fun updateNav() {
        tabCounts.forEach { it.text = tabs.size.toString() }
    }

    private fun hideKeyboard(v: View) {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    private fun openStudio() {
        try {
            startActivity(Intent(this, ThemeStudioActivity::class.java))
        } catch (e: Exception) {
            Toast.makeText(this, "Не вдалося відкрити Theme Studio", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────── атмосфера ─────────

    @Suppress("DEPRECATION")
    private fun applyBars(t: AeroTheme) {
        val base = when (t.bgMode) {
            1, 2 -> avgStops(t.stops, t.background)
            3 -> t.background
            else -> t.background
        }
        window.statusBarColor = base
        window.navigationBarColor = base
        val light = lum(base) > 0.5
        val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (light) mask else 0, mask)
    }

    /** Повільний дрейф світлових плям: фон "дихає", а скло розмиває вже оновлену картинку. */
    private fun updateAmbient(t: AeroTheme) {
        ambient?.cancel()
        ambient = null
        val scale = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        if (t.anim == 0 || scale <= 0f) return
        ambient = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
            duration = 24000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastAmb >= 45) {
                    lastAmb = now
                    bg?.phase = it.animatedValue as Float
                    bg?.invalidateSelf()
                    glass.forEach { g -> g.invalidate() }
                }
            }
            start()
        }
    }
}
